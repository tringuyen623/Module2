<style>
    /*.header_logo .logo a { background: url(https://cafef.mediacdn.vn/web_images/logoTet.png) 0 -7px no-repeat !important; height: 40px; width: 230px; }
    .header_logo .logo { margin-top: 0; margin-left: -70px; }*/
    /*.header_logo .logo a { background: url(http://cafef.mediacdn.vn/web_images/logo_noel.jpg) no-repeat !important; height: 36px; width: 177px; }
    .header_logo .logo { margin-top: 2px; }
    @media screen and  (max-width: 1280px) {
        .cate-page .header_logo .logo { margin-left: -30px; }
    }*/
    .header_new .menupage a.logowechoice { width: 132px; height: 27px; border: none; margin-bottom: 35px; }
    .header_new .menupage a:not(.logowechoice) { z-index: 9;position: relative; }
    .logowechoice img { width: 100%; }
    .header_new .menupage { margin-top: 8px; }
</style>
