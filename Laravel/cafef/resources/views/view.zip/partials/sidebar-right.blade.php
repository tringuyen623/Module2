<div class="sidebar_right">

    <div class="searchboxwp">

        <div id="CafeF_BoxSearchNew">  <div class="searchbox clearfix">        <input class="textbox s-input ac_input" type="text" placeholder="Gõ mã CK hoặc tên công ty..." id="CafeF_SearchKeyword_Company" autocomplete="off">        <input class="textbox s-input" type="text" placeholder="Tìm kiếm tin tức..." id="CafeF_SearchKeyword_News" style="display: none;">        <input class="textbox s-input ac_input" type="text" placeholder="Gõ họ tên..." id="CafeF_SearchKeyword_Ceo" style="display: none;" autocomplete="off">      <a href="javascript:void(0)" rel="nofollow" class="bt_search sprite s-submit"></a>   </div>  <div class="checked">      <input class="mg0" type="radio" checked="checked" id="CafeF_BoxSearch_Type_Company" name="CafeF_BoxSearch_Type" value="0"><label>Công ty</label>     <input type="radio" id="CafeF_BoxSearch_Type_News" name="CafeF_BoxSearch_Type" value="1"><label>Tin tức</label>      <input type="radio" id="CafeF_BoxSearch_Type_Ceo" name="CafeF_BoxSearch_Type" value="2"><label>Lãnh đạo</label>    </div></div>


    </div>


                        <div class="banner_right1" style="border: none;">


    <div class="clr">
        <div id="admzone97"><div style="margin:auto">
    <div id="zone-97"><div id="share-jxcllukp"><div id="placement-k4tdr1vx" revenue="cpd"><div id="banner-97-k4tdr2qd" style="min-height: 0px; min-width: 0px;"><div id="slot-1-97-k4tdr2qd"><iframe width="300" height="385" id="iframe-97-k4tdr2qd" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" style="display: block; width: 100%;"></iframe></div></div></div><div id="placement-363045" revenue="pb"><div id="banner-97-395316" style="min-height: 0px; min-width: 0px;"><div id="slot-1-97-395316"><div id="nativezone_510711_1169" data-admssprqid="a73f3297-80ed-46a9-aaf5-537409ec567b-5e1495ec" data-width="300" data-height="250" data-ssp="sspbid_1169"><iframe style="width: 300px; height: 280px; border: none; z-index: 2; position: relative;" id="native_ad_ifr_510711_1169" src="javascript:void(0)" data-bid="556687" scrolling="no" frameborder="no"></iframe></div><script type="text/javascript">admsspreg({sspid:1169,w:300,h:250});</script></div></div></div></div> </div>
    </div>
    <div id="advBalloon300x385" style="clear:both"></div></div>
        <script>
            admicroAD.unit.push(function () { admicroAD.show('admzone97') });
        </script>


    </div>
                            <div class="mgt20 clearfix">
                                <div id="admzone514705"><div id="zone-514705"><div id="share-jvbu4hxw"><div id="placement-k52p85bx" revenue="cpd"><div id="banner-514705-k52p8602" style="min-height: 10px; min-width: 10px;"><div id="slot-1-514705-k52p8602"><iframe width="300" height="600" id="iframe-514705-k52p8602" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" style="display: block; width: 100%;"></iframe></div></div></div></div> </div></div>
                                <script>
                                    admicroAD.unit.push(function () { admicroAD.show('admzone514705') });
                                </script>
                            </div>
                        </div>


    <div id="admzone509427"><div id="zone-509427"><div id="share-jtgyrifd"><div id="placement-565909" revenue="cpm"><div id="banner-509427-565909" style="min-height: 10px; min-width: 10px;"><div id="slot-1-509427-565909"><div id="admbanggia1" width="300" height="282"><iframe src="https://adi.admicro.vn/adt/banners/nam2015/2033/boxtaitro/tygia_box1.html" width="300" height="282" frameborder="0" scrolling="no"></iframe></div>
    <script>
        (function() {
            var doc = document;
            var admid = 'zone';
            var zone = parent.document.getElementById('admbanggia1');
            var wd = 300;
            var hg = 282;
            var url = 'https://adi.admicro.vn/adt/banners/nam2015/2033/boxtaitro/tygia_box1.html';
            zone.setAttribute('width',wd);
            zone.setAttribute('height',hg);
            doc.getElementById('admbanggia1').innerHTML=('<ifr' + 'ame src="' + url + '" width="' + wd + '" height="' + hg + '" frameborder="0" scrolling="no"></ifr' + 'ame>');
        })();
    </script></div></div></div><div id="placement-559076" revenue="cpm"><div id="banner-509427-559076" style="min-height: 10px; min-width: 10px;"><div id="slot-1-509427-559076"><div id="admbanggia2" width="300" height="145"><iframe src="https://adi.admicro.vn/adt/banners/nam2015/2033/boxtaitro/tygia_box2.html" width="300" height="145" frameborder="0" scrolling="no"></iframe></div>
    <script>
        (function() {
            var doc = document;
            var admid = 'zone';
            var zone = parent.document.getElementById('admbanggia2');
            var wd = 300;
            var hg = 145;
            var url = 'https://adi.admicro.vn/adt/banners/nam2015/2033/boxtaitro/tygia_box2.html';
            zone.setAttribute('width',wd);
            zone.setAttribute('height',hg);
            doc.getElementById('admbanggia2').innerHTML=('<ifr' + 'ame src="' + url + '" width="' + wd + '" height="' + hg + '" frameborder="0" scrolling="no"></ifr' + 'ame>');
        })();
    </script></div></div></div><div id="placement-569983" revenue="cpm"><div id="banner-509427-569983" style="min-height: 10px; min-width: 10px;"><div id="slot-1-509427-569983"><div id="admbanggia3" width="300" height="145"><iframe src="https://adi.admicro.vn/adt/banners/nam2015/2033/boxtaitro/tygia_box3.html" width="300" height="145" frameborder="0" scrolling="no"></iframe></div>
    <script>
        (function() {
            var doc = document;
            var admid = 'zone';
            var zone = parent.document.getElementById('admbanggia3');
            var wd = 300;
            var hg = 145;
            var url = 'https://adi.admicro.vn/adt/banners/nam2015/2033/boxtaitro/tygia_box3.html';
            zone.setAttribute('width',wd);
            zone.setAttribute('height',hg);
            doc.getElementById('admbanggia3').innerHTML=('<ifr' + 'ame src="' + url + '" width="' + wd + '" height="' + hg + '" frameborder="0" scrolling="no"></ifr' + 'ame>');
        })();
    </script></div></div></div></div> </div></div>
    <script>
        admicroAD.unit.push(function () { admicroAD.show('admzone509427') });
    </script>



                        <div id="admzone489108"><div id="zone-489108"><div id="share-jtgyri8n"><div id="placement-559076" revenue="cpm"><div id="banner-489108-559076" style="min-height: 10px; min-width: 10px;"><div id="slot-1-489108-559076"><div id="admbanggia2"></div>
    <script>
        (function() {
            var doc = document;
            var admid = 'zone';
            var zone = parent.document.getElementById('admbanggia2');
            var wd = 300;
            var hg = 145;
            var url = 'https://adi.admicro.vn/adt/banners/nam2015/2033/boxtaitro/tygia_box2.html';
            zone.setAttribute('width',wd);
            zone.setAttribute('height',hg);
            doc.getElementById('admbanggia2').innerHTML=('<ifr' + 'ame src="' + url + '" width="' + wd + '" height="' + hg + '" frameborder="0" scrolling="no"></ifr' + 'ame>');
        })();
    </script></div></div></div></div> </div></div>
                        <script>
                            admicroAD.unit.push(function () { admicroAD.show('admzone489108') });
                        </script>

                        <div class="banner_right2">
                            <div class="list3box clearfix mgb15 mgt15">

    <div class="left" id="ListLichSuKien">
        <h2 class="title_box"><a href="http://s.cafef.vn/lich-su-kien.chn" title="LỊCH SỰ KIỆN"><span class="icon_time sprite"></span>LỊCH SỰ KIỆN</a></h2>
    <div class="mgt10"><div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 500px;"><ul class="list listlichsk" style="overflow: hidden; width: auto; height: 500px;"><div class="listevent-inner"><li class="time top clearfix"><p>07/01</p></li><div class="listGroupLichSuKien"><li class="event"><span class="ma">KIP</span><a href="http://s.cafef.vn/upcom/KIP-cong-ty-co-phan-kip-viet-nam.chn" title="Trả cổ tức bằng tiền mặt (1.000đ/cp)" target="_blank">Trả cổ tức bằng tiền mặt (1.000đ/cp)</a></li><li class="event"><span class="ma">PVG</span><a href="http://s.cafef.vn/hastc/PVG-cong-ty-co-phan-kinh-doanh-khi-mien-bac.chn" title="Đại hội đồng cổ đông bất thường năm 2020" target="_blank">Đại hội đồng cổ đông bất thường năm 2020</a></li><li class="event"><span class="ma">BVH</span><a href="http://s.cafef.vn/hose/BVH-tap-doan-bao-viet.chn" title="Niêm yết bổ sung 41.436.330 cp" target="_blank">Niêm yết bổ sung 41.436.330 cp</a></li><li class="event no_border"><span class="ma">E1V</span><a href="http://s.cafef.vn/hose/E1VFVN30-quy-etf-vfmvn30.chn" title="Giao dịch 1.500.000 ccq niêm yết bổ sung" target="_blank">Giao dịch 1.500.000 ccq niêm yết bổ sung</a></li></div><li class="time top clearfix"><p>08/01</p></li><div class="listGroupLichSuKien"><li class="event"><span class="ma">VHI</span><a href="http://s.cafef.vn/upcom/VHI-ctcp-kinh-doanh-va-dau-tu-viet-ha.chn" title="Giao dịch 76.900.000 cổ phiếu đăng ký giao dịch" target="_blank">Giao dịch 76.900.000 cổ phiếu đăng ký giao dịch</a></li><li class="event"><span class="ma">DUS</span><a href="http://s.cafef.vn/upcom/DUS-ctcp-dich-vu-do-thi-da-lat.chn" title="Giao dịch 5.614.300 cổ phiếu đăng ký giao dịch" target="_blank">Giao dịch 5.614.300 cổ phiếu đăng ký giao dịch</a></li><li class="event"><span class="ma">GTK</span><a href="http://s.cafef.vn/upcom/GTK-cong-ty-co-phan-giay-thuy-khue.chn" title="Giao dịch 7.700.000 cổ phiếu đăng ký giao dịch" target="_blank">Giao dịch 7.700.000 cổ phiếu đăng ký giao dịch</a></li><li class="event"><span class="ma">LCG</span><a href="http://s.cafef.vn/hose/LCG-cong-ty-co-phan-licogi-16.chn" title="Niêm yết bổ sung 4.899.293 cp" target="_blank">Niêm yết bổ sung 4.899.293 cp</a></li><li class="event no_border"><span class="ma">PVL</span><a href="http://s.cafef.vn/hastc/PVL-cong-ty-co-phan-dau-tu-nha-dat-viet.chn" title="Đại hội đồng cổ đông thường niên năm 2020" target="_blank">Đại hội đồng cổ đông thường niên năm 2020</a></li></div><li class="time top clearfix"><p>09/01</p></li><div class="listGroupLichSuKien"><li class="event"><span class="ma">GSP</span><a href="http://s.cafef.vn/hose/GSP-cong-ty-co-phan-van-tai-san-pham-khi-quoc-te.chn" title="Giao dịch 6.000.000 cp niêm yết bổ sung" target="_blank">Giao dịch 6.000.000 cp niêm yết bổ sung</a></li><li class="event"><span class="ma">QNT</span><a href="http://s.cafef.vn/upcom/QNT-trung-tam-tu-van-xay-dung-thi-xa-dien-ban.chn" title="Giao dịch 134.050 cổ phần đăng ký giao dịch" target="_blank">Giao dịch 134.050 cổ phần đăng ký giao dịch</a></li><li class="event"><span class="ma">GQN</span><a href="http://s.cafef.vn/upcom/GQN-trung-tam-giong-thuy-san-quang-nam.chn" title="Giao dịch 846.000 cổ phần đăng ký giao dịch" target="_blank">Giao dịch 846.000 cổ phần đăng ký giao dịch</a></li><li class="event"><span class="ma">CE1</span><a href="http://s.cafef.vn/upcom/CE1-cong-ty-co-phan-xay-dung-va-thiet-bi-cong-nghiep-cie1.chn" title="Trả cổ tức bằng tiền mặt (300đ/cp)" target="_blank">Trả cổ tức bằng tiền mặt (300đ/cp)</a></li><li class="event"><span class="ma">UDL</span><a href="http://s.cafef.vn/upcom/UDL-ctcp-do-thi-va-moi-truong-dak-lak.chn" title="Giao dịch 6.620.000 cổ phiếu đăng ký giao dịch" target="_blank">Giao dịch 6.620.000 cổ phiếu đăng ký giao dịch</a></li><li class="event"><span class="ma">TLH</span><a href="http://s.cafef.vn/hose/TLH-cong-ty-co-phan-tap-doan-thep-tien-len.chn" title="Trả cổ tức đợt 3 năm 2017 (500 đ/cp)" target="_blank">Trả cổ tức đợt 3 năm 2017 (500 đ/cp)</a></li><li class="event no_border"><span class="ma">NT2</span><a href="http://s.cafef.vn/hose/NT2-cong-ty-co-phan-dien-luc-dau-khi-nhon-trach-2.chn" title="Tạm ứng cổ tức đợt 1 năm 2019 (1.000 đ/cp)" target="_blank">Tạm ứng cổ tức đợt 1 năm 2019 (1.000 đ/cp)</a></li></div><li class="time top clearfix"><p>10/01</p></li><div class="listGroupLichSuKien"><li class="event"><span class="ma">AMS</span><a href="http://s.cafef.vn/upcom/AMS-cong-ty-co-phan-co-khi-xay-dung-amecc.chn" title="Giao dịch 3.300.000 cổ phiếu niêm yết bổ sung" target="_blank">Giao dịch 3.300.000 cổ phiếu niêm yết bổ sung</a></li><li class="event"><span class="ma">MEF</span><a href="http://s.cafef.vn/upcom/MEF-cong-ty-co-phan-meinfa.chn" title="Giao dịch 185.309 cổ phiếu niêm yết bổ sung" target="_blank">Giao dịch 185.309 cổ phiếu niêm yết bổ sung</a></li><li class="event no_border"><span class="ma">GAB</span><a href="http://s.cafef.vn/hose/GAB-cong-ty-co-phan-gab.chn" title="ĐHCĐ bất thường năm 2020" target="_blank">ĐHCĐ bất thường năm 2020</a></li></div><li class="time top clearfix"><p>13/01</p></li><div class="listGroupLichSuKien"><li class="event"><span class="ma">HSG</span><a href="http://s.cafef.vn/hose/HSG-cong-ty-co-phan-tap-doan-hoa-sen.chn" title="ĐHĐCĐ thường niên niên độ tài chính 2019-2020" target="_blank">ĐHĐCĐ thường niên niên độ tài chính 2019-2020</a></li><li class="event"><span class="ma">ISH</span><a href="http://s.cafef.vn/upcom/ISH-cong-ty-co-phan-thuy-dien-srok-phu-mieng-idico.chn" title="Trả cổ tức bằng tiền mặt (1.000đ/cp)" target="_blank">Trả cổ tức bằng tiền mặt (1.000đ/cp)</a></li><li class="event no_border"><span class="ma">TTC</span><a href="http://s.cafef.vn/hastc/TTC-cong-ty-co-phan-gach-men-thanh-thanh.chn" title="ĐHĐCĐ bất thường năm 2019, trả cổ tức bằng tiền mặt (1.500 đ/cp)" target="_blank">ĐHĐCĐ bất thường năm 2019, trả cổ tức bằng tiền mặt (1.500 đ/cp)</a></li></div><li class="time top clearfix"><p>14/01</p></li><div class="listGroupLichSuKien"><li class="event"><span class="ma">GTA</span><a href="http://s.cafef.vn/hose/GTA-cong-ty-co-phan-che-bien-go-thuan-an.chn" title="Tổ chức ĐHĐCĐ thường niên năm 2020" target="_blank">Tổ chức ĐHĐCĐ thường niên năm 2020</a></li><li class="event"><span class="ma">ATG</span><a href="http://s.cafef.vn/hose/ATG-cong-ty-co-phan-an-truong-an.chn" title="ĐHĐCĐ thường niên 2019 lần 2" target="_blank">ĐHĐCĐ thường niên 2019 lần 2</a></li><li class="event no_border"><span class="ma">AGF</span><a href="http://s.cafef.vn/hose/AGF-cong-ty-co-phan-xuat-nhap-khau-thuy-san-an-giang.chn" title="ĐHĐCĐ thường niên năm 2020" target="_blank">ĐHĐCĐ thường niên năm 2020</a></li></div><li class="time top clearfix"><p>15/01</p></li><div class="listGroupLichSuKien"><li class="event"><span class="ma">CTD</span><a href="http://s.cafef.vn/hose/CTD-cong-ty-co-phan-xay-dung-coteccons.chn" title="Giao dịch 1.305.000 cp niêm yết bổ sung " target="_blank">Giao dịch 1.305.000 cp niêm yết bổ sung </a></li><li class="event"><span class="ma">S55</span><a href="http://s.cafef.vn/hastc/S55-cong-ty-co-phan-song-da-505.chn" title="Đại hội đồng cổ đông thường niên năm 2020" target="_blank">Đại hội đồng cổ đông thường niên năm 2020</a></li><li class="event"><span class="ma">VPB</span><a href="http://s.cafef.vn/hose/VPB-ngan-hang-thuong-mai-co-phan-viet-nam-thinh-vuong.chn" title="Lấy ý kiến cổ đông bằng văn bản" target="_blank">Lấy ý kiến cổ đông bằng văn bản</a></li><li class="event"><span class="ma">ICT</span><a href="http://s.cafef.vn/otc/ICT-cong-ty-co-phan-vien-thong-tin-hoc-buu-dien.chn" title="Giao dịch lần đầu 32.185.000 cp" target="_blank">Giao dịch lần đầu 32.185.000 cp</a></li><li class="event no_border"><span class="ma">SZB</span><a href="http://s.cafef.vn/hastc/SZB-cong-ty-co-phan-sonadezi-long-binh.chn" title="Lấy ý kiến cổ đông bằng văn bản" target="_blank">Lấy ý kiến cổ đông bằng văn bản</a></li></div><li class="time top clearfix"><p>16/01</p></li><div class="listGroupLichSuKien"><li class="event no_border"><span class="ma">POM</span><a href="http://s.cafef.vn/hose/POM-cong-ty-co-phan-thep-pomina.chn" title="Trả cổ tức năm 2018 (tỷ lệ 100:15)" target="_blank">Trả cổ tức năm 2018 (tỷ lệ 100:15)</a></li></div><li class="time top clearfix"><p>17/01</p></li><div class="listGroupLichSuKien"><li class="event no_border"><span class="ma">NTT</span><a href="http://s.cafef.vn/upcom/NTT-cong-ty-co-phan-det-may-nha-trang.chn" title="Lấy ý kiến cổ đông bằng văn bản" target="_blank">Lấy ý kiến cổ đông bằng văn bản</a></li></div></div></ul><div class="slimScrollBar" style="background: rgb(198, 198, 198); width: 3px; position: absolute; top: 0px; opacity: 1; display: block; border-radius: 7px; z-index: 99; right: 1px; height: 143.021px;"></div><div class="slimScrollRail" style="width: 3px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div></div></div>

                            </div>
                            <div class="list3box mgb15">

    <div class="center" id="companyinfo-box">
        <h2 class="title_box">
            <a href="http://s.cafef.vn/tin-doanh-nghiep.chn" title="Tin tức doanh nghiệp niêm yết">TIN TỨC DOANH NGHIỆP NIÊM YẾT</a>
        </h2>
        <div id="cn-content" class="mgt10"><div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 500px;"><ul class="hCompany" style="overflow: hidden; width: auto; height: 500px;"><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            16:47
                        ">
                            16:47
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/DBC-cong-ty-co-phan-tap-doan-dabaco-viet-nam.chn" class="symbol" rel="DBC" title="DBC">DBC</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/DBC-334202/dabaco-dat-muc-tieu-lai-sau-thue-457-ty-dong-nam-2020-uoc-tang-truong-28.chn">Dabaco đặt mục tiêu lãi sau thuế 457 tỷ đồng năm...</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            25.0
                            <span class="up">
                                +0.3
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            15:11
                        ">
                            15:11
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/TCL-cong-ty-co-phan-dai-ly-giao-nhan-van-tai-xep-do-tan-cang.chn" class="symbol" rel="TCL" title="TCL">TCL</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/TCL-332598/tcl-30122019-ngay-gdkhq-thuong-cp-ty-le-10044.chn">TCL: 30.12.2019, ngày GDKHQ thưởng cp (tỷ...</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            20.2
                            <span class="up">
                                +0.4
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            14:02
                        ">
                            14:02
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/SJS-cong-ty-co-phan-dau-tu-phat-trien-do-thi-va-khu-cong-nghiep-song-da.chn" class="symbol" rel="SJS" title="SJS">SJS</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/SJS-334112/pho-chu-tich-sudico-vua-ban-bot-69-trieu-co-phieu-sjs.chn">Phó Chủ tịch Sudico vừa bán bớt 6,9 triệu cổ phiếu SJS</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            16.4
                            <span class="up">
                                +0.4
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            14:01
                        ">
                            14:01
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/CDC-cong-ty-co-phan-chuong-duong.chn" class="symbol" rel="CDC" title="CDC">CDC</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/CDC-334109/chuong-duong-corp-cdc-bi-phat-va-truy-thu-hon-2-ty-dong-tien-thue.chn">Chương Dương Corp (CDC) bị phạt và truy thu hơn 2...</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            16.4
                            <span class="up">
                                +0.4
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            13:26
                        ">
                            13:26
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/PXI-cong-ty-co-phan-xay-dung-cong-nghiep-va-dan-dung-dau-khi.chn" class="symbol" rel="PXI" title="PXI">PXI</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/PXI-334189/pxi-nhac-nho-cham-cong-bo-quyet-dinh-cua-co-quan-thue.chn">PXI: Nhắc nhở chậm công bố Quyết định của cơ quan thuế</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            3.0
                            <span class="up">
                                +0.0
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            13:26
                        ">
                            13:26
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/SCD-cong-ty-co-phan-nuoc-giai-khat-chuong-duong.chn" class="symbol" rel="SCD" title="SCD">SCD</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/SCD-334188/scd-ctcp-tu-van-va-dau-tu-mao-hiem-da-ban-20000-cp.chn">SCD: CTCP Tư vấn và Đầu tư Mạo hiểm đã bán 20.000 cp</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            27.9
                            <span class="down">
                                -0.1
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            13:23
                        ">
                            13:23
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/CSM-cong-ty-co-phan-cong-nghiep-cao-su-mien-nam.chn" class="symbol" rel="CSM" title="CSM">CSM</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/CSM-334190/csm-ba-le-thi-thu-thuy-tvbks-dang-ky-ban-20000-cp.chn">CSM: Bà Lê Thị Thu Thủy - TV.BKS đăng ký bán...</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            14.3
                            <span class="up">
                                +0.4
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            13:23
                        ">
                            13:23
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/DBD-cong-ty-co-phan-duoc-trang-thiet-bi-y-te-binh-dinh.chn" class="symbol" rel="DBD" title="DBD">DBD</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/DBD-334191/dbd-bien-ban-kiem-phieu-va-nghi-quyet-dhdcd-bat-thuong-bang-van-ban-nam-2019.chn">DBD: Biên bản kiểm phiếu và Nghị quyết ĐHĐCĐ...</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            55.0
                            <span class="up">
                                +0.1
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            13:20
                        ">
                            13:20
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/CII-cong-ty-co-phan-dau-tu-ha-tang-ky-thuat-tp-ho-chi-minh.chn" class="symbol" rel="CII" title="CII">CII</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/CII-334193/cii-ket-qua-kinh-doanh-nam-2019.chn">CII: Kết quả kinh doanh năm 2019</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            23.3
                            <span class="up">
                                +0.3
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            13:20
                        ">
                            13:20
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/TCL-cong-ty-co-phan-dai-ly-giao-nhan-van-tai-xep-do-tan-cang.chn" class="symbol" rel="TCL" title="TCL">TCL</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/TCL-334192/tcl-so-luong-co-phieu-co-quyen-bieu-quyet-dang-luu-hanh-la-30158436-cp.chn">TCL: Số lượng cổ phiếu có quyền biểu quyết đang...</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            20.2
                            <span class="up">
                                +0.4
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            10:47
                        ">
                            10:47
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/EVG-cong-ty-co-phan-dau-tu-everland.chn" class="symbol" rel="EVG" title="EVG">EVG</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/EVG-334194/evg-ba-cao-thi-huyen-my-da-ban-1066580-cp-khong-con-la-cdl.chn">EVG: Bà Cao Thị Huyền My đã bán 1.066.580 cp...</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            2.5
                            <span class="down">
                                0.0
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            10:44
                        ">
                            10:44
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/HRC-cong-ty-co-phan-cao-su-hoa-binh.chn" class="symbol" rel="HRC" title="HRC">HRC</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/HRC-334195/hrc-bo-nhiem-lai-ong-vo-bao-lam-tgd-tu-612020.chn">HRC: Bổ nhiệm lại ông Võ Bảo làm TGĐ từ 6.1.2020</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            43.6
                            <span class="up">
                                +1.6
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            10:44
                        ">
                            10:44
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/KMR-cong-ty-co-phan-mirae.chn" class="symbol" rel="KMR" title="KMR">KMR</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/KMR-334196/kmr-quyet-dinh-cua-cuc-thue-tinh-binh-duong-vv-xu-phat-thue-nam-20162018.chn">KMR: Quyết định của Cục thuế Tỉnh Bình Dương v/v...</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            2.7
                            <span class="down">
                                0.0
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            09:53
                        ">
                            09:53
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/PAN-cong-ty-co-phan-tap-doan-pan.chn" class="symbol" rel="PAN" title="PAN">PAN</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/PAN-333963/pan-group-chot-danh-sach-co-dong-phat-hanh-43-trieu-co-phieu-thuong-ty-le-25.chn">PAN Group chốt danh sách cổ đông phát hành 43...</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            28.0
                            <br><span class="">
                                0.0
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            09:53
                        ">
                            09:53
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/HVG-cong-ty-co-phan-hung-vuong.chn" class="symbol" rel="HVG" title="HVG">HVG</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/HVG-333962/truoc-them-ky-ket-chien-luoc-voi-thaco-hvg-chi-hon-300-ty-mua-them-von-tai-thuy-san-hung-vuong-mien-tay-de-ban-lai.chn">Trước thềm ký kết chiến lược với THACO, HVG chi hơn...</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            8.6
                            <span class="up">
                                +0.6
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            09:23
                        ">
                            09:23
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/GAB-cong-ty-co-phan-gab.chn" class="symbol" rel="GAB" title="GAB">GAB</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/GAB-334197/gab-1012020-ngay-gdkhq-thuc-hien-quyen-tham-du-dhcd-bat-thuong-nam-2020.chn">GAB: 10.1.2020, ngày GDKHQ thực hiện...</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            21.2
                            <span class="up">
                                +1.4
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            09:23
                        ">
                            09:23
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/LCG-cong-ty-co-phan-licogi-16.chn" class="symbol" rel="LCG" title="LCG">LCG</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/LCG-334198/lcg-812020-niem-yet-bo-sung-4899293-cp.chn">LCG: 8.1.2020, niêm yết bổ sung 4.899.293 cp</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            7.8
                            <span class="down">
                                -0.1
                        </span></div></li><li class="clearfix"><div class="company-left cib-cell" style="width: 33px;"><span class="time" title="
                            09:15
                        ">
                            09:15
                        </span><span class="ma"><a href="http://s.cafef.vn/hose/E1VFVN30-quy-etf-vfmvn30.chn" class="symbol" rel="E1VFVN30" title="E1VFVN30">E1V</a></span></div><div class="company-center cib-cell" style="width: 170px;">
                            <a href="/E1VFVN30-334200/e1vfvn30-712020-giao-dich-1500000-ccq-niem-yet-bo-sung.chn">E1VFVN30: 7.1.2020, giao dịch 1.500.000 ccq niêm...</a>
                        </div><div class="company-right cib-cell" style="width: 47px;">
                            14.6
                            <span class="down">
                                0.0
                        </span></div></li></ul><div class="slimScrollBar" style="background: rgb(198, 198, 198); width: 3px; position: absolute; top: 0px; opacity: 1; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 249.32px;"></div><div class="slimScrollRail" style="width: 3px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div></div>
        <div class="hidden" id="cn-loaded"></div>
    </div>

                            </div>



    <div class="clr mgt15">
        <div id="admzone99"><script>
    (function(){
    var bindCSS=function(c){var e=document.createElement("style");e.type="text/css";document.getElementsByTagName("head")[0].appendChild(e);e.styleSheet?e.styleSheet.cssText=c:e.appendChild(document.createTextNode(c))};
    bindCSS('#companyinfo-box{margin-bottom:10px;}');
    })();
    </script>

    <div id="zone-99"><div id="share-jtgyrgq0"><div id="placement-k382bea3" revenue="cpd"><div id="banner-99-k382betw" style="min-height: 0px; min-width: 0px;"><div id="slot-1-99-k382betw"><iframe width="300" height="600" id="iframe-99-k382betw" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" style="display: block; width: 100%;"></iframe></div></div></div></div> </div></div>
        <script>
            admicroAD.unit.push(function () { admicroAD.show('admzone99') });
        </script>
    </div>
                        </div>

                        </div>
