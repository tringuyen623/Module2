<div class="noibat_home clearfix">
@include('partials.newleft')
@include('partials.sidebar-right')
</div>
<div class="clearfix"></div>
