<div class="bannertop w100pt">
    <div class="wp1040">
        <div class="ads_center mgt10">



<div id="admzone96"><div id="zone-96"><div id="share-jtgyrgpv"><div id="placement-k455xg0x" revenue="cpd"><div id="banner-96-k455xgmm" style="min-height: 0px; min-width: 0px;"><div id="slot-1-96-k455xgmm"><iframe width="1040" height="90" id="iframe-96-k455xgmm" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" style="display: block; height: 250px; width: 100%; transition: height 2s ease-out 0s;"></iframe></div></div></div></div> </div></div>
<script>
    admicroAD.unit.push(function () { admicroAD.show('admzone96') });
</script>


        </div>
    </div>
</div>
<div class="clearfix"></div>
