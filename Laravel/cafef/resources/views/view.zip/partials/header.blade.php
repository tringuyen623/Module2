<div class="header clearfix">
    <div class="header_logo">
        <div class="wp1040 relative">
            <div class="logo">
                <h1><a href="/" class="sprite" title="Kênh thông tin kinh tế - tài chính Việt Nam"></a></h1>
            </div>
            <div class="xembanthunghiem">Xem bản thử nghiệm <i class="iconthunghiemoff" onclick="ClickBeta()"></i></div>





<div class="mack" id="CafeF_StockSymbolContainer">
    <div id="macktheodoi" class="inner" data-type="stock-container"><ul><li class="wait only1024" title="Click vào đây để chọn mã chứng khoán cần theo dõi">Chọn mã CK<br>cần theo dõi</li><li class="wait only1024" title="Click vào đây để chọn mã chứng khoán cần theo dõi">Chọn mã CK<br>cần theo dõi</li><li class="wait only1024" title="Click vào đây để chọn mã chứng khoán cần theo dõi">Chọn mã CK<br>cần theo dõi</li><li class="wait only1024" title="Click vào đây để chọn mã chứng khoán cần theo dõi">Chọn mã CK<br>cần theo dõi</li><li class="wait only1024" title="Click vào đây để chọn mã chứng khoán cần theo dõi">Chọn mã CK<br>cần theo dõi</li><li class="wait only1024 end1024" title="Click vào đây để chọn mã chứng khoán cần theo dõi">Chọn mã CK<br>cần theo dõi</li><li class="wait end" title="Click vào đây để chọn mã chứng khoán cần theo dõi">Chọn mã CK<br>cần theo dõi</li></ul><a href="javascript:void(0);" class="icon_dropdown sprite"><i class="inner"></i></a><div class="clearmck"><div id="CafeF_StockSymbolSlidePopup" class="add-stock-popup"><div class="popup-row"><div class="in-placeholder"><input type="text" id="CafeF_StockSymbolSlideKeyword" placeholder="Mã chứng khoán muốn theo dõi..." autocomplete="off" class="class_text_autocomplete ac_input txt-symbol"><a href="javascript:void(0);" id="btn_addsymbol" class="btn-addsymbol"></a></div></div><div class="popup-row list-wrapper" id="CafeF_StockSymbolSlidePopupList"></div><div class="popup-row"><a href="javascript:void(0);" id="btn_removesymbol" class="btn-removesymbol"><i class="ico-remove"></i>Xóa toàn bộ</a></div><div class="clearfix" id="topprice-placeholder"></div></div></div></div>
</div>

        </div>
    </div>
    <div class="header_new clearfix">
        <div class="wp1040">
            <div class="menupage">

                <a class="sprite top isent" href="/gui-tin-nhanh.chn" title="Gửi tin nhanh"><span class="icon_sent"></span>Gửi tin nhanh</a>
                <a class="idautu" href="http://liveboard.cafef.vn" target="_blank" rel="nofollow" title="Bản giá điện tử"><span class="icon_sent sprite"></span>Bảng giá điện tử</a>
                <a class="sprite end itable" target="_blank" rel="nofollow" href="http://s.cafef.vn/danh-muc-dau-tu.chn" title="Danh mục đầu tư"><span class="icon_sent"></span>Danh mục đầu tư</a>
            </div>

<div class="tinmoi">
    <div class="title_box">
        <p class="title_left">TIN MỚI!</p>
        <a href="/doc-nhanh.chn" title="đọc nhanh" class="doctinnhanh">Đọc nhanh &gt;&gt;</a>
    </div>
    <div class="clearfix"></div>
    <div class="list_news">
        <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 155px;"><div id="listNewHeader" dmtb="4" style="overflow: hidden; width: auto; height: 155px;">
            <ul>

                        <li data-id="20200107161456986"><span class="time timeliveheader" data-month="01" data-date="07">21:05</span><span class="border_split" style="height: 25px;"></span><a title="Thái Lan: Đồng Baht không phải là “vịnh tránh bão” trong căng thẳng Mỹ-Iran" href="//lg1.logging.admicro.vn/nd?nid=20200107161456986&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fthai-lan-dong-baht-khong-phai-la-vinh-tranh-bao-trong-cang-thang-my-iran-20200107161456986.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Thái Lan: Đồng Baht không phải là “vịnh tránh bão” trong căng thẳng Mỹ-Iran</span></a></li>

                        <li data-id="20200107085207064"><span class="time timeliveheader" data-month="01" data-date="07">21:04</span><span class="border_split" style="height: 25px;"></span><a title="Uống nước nhiều nhưng vẫn thấy khô miệng, hãy cẩn thận bởi đây là dấu hiệu của hàng loạt bệnh nguy hiểm" href="//lg1.logging.admicro.vn/nd?nid=20200107085207064&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fuong-nuoc-nhieu-nhung-van-thay-kho-mieng-hay-can-than-boi-day-la-dau-hieu-cua-hang-loat-benh-nguy-hiem-20200107085207064.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Uống nước nhiều nhưng vẫn thấy khô miệng, hãy cẩn thận bởi đây là dấu hiệu của hàng loạt bệnh nguy hiểm</span></a></li>

                        <li data-id="20200107112719689"><span class="time timeliveheader" data-month="01" data-date="07">21:03</span><span class="border_split" style="height: 25px;"></span><a title="Ô nhiễm không khí chẳng những tăng nguy cơ mắc ung thư, trầm cảm mà còn là thủ phạm gây nên loại bệnh chị em nào cũng sợ" href="//lg1.logging.admicro.vn/nd?nid=20200107112719689&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fo-nhiem-khong-khi-chang-nhung-tang-nguy-co-mac-ung-thu-tram-cam-ma-con-la-thu-pham-gay-nen-loai-benh-chi-em-nao-cung-so-20200107112719689.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Ô nhiễm không khí chẳng những tăng nguy cơ mắc ung thư, trầm cảm mà còn là thủ phạm gây nên loại bệnh chị em nào cũng sợ</span></a></li>

                        <li data-id="20200107210112127"><span class="time timeliveheader" data-month="01" data-date="07">21:01</span><span class="border_split" style="height: 10px;"></span><a title="Cựu Bộ trưởng Nguyễn Bắc Son kháng cáo xin hưởng khoan hồng" href="//lg1.logging.admicro.vn/nd?nid=20200107210112127&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fcuu-bo-truong-nguyen-bac-son-khang-cao-xin-huong-khoan-hong-20200107210112127.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Cựu Bộ trưởng Nguyễn Bắc Son kháng cáo xin hưởng khoan hồng</span></a></li>

                        <li data-id="2020010715231272"><span class="time timeliveheader" data-month="01" data-date="07">21:00</span><span class="border_split" style="height: 10px;"></span><a title="Căn hộ nội thất màu đen vô cùng huyền bí và sang trọng" href="//lg1.logging.admicro.vn/nd?nid=2020010715231272&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fcan-ho-noi-that-mau-den-vo-cung-huyen-bi-va-sang-trong-2020010715231272.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Căn hộ nội thất màu đen vô cùng huyền bí và sang trọng</span></a></li>

                        <li data-id="20200107165507064"><span class="time timeliveheader" data-month="01" data-date="07">20:49</span><span class="border_split" style="height: 25px;"></span><a title="Ô nhiễm bụi mịn ở Hà Nội, người dân chuyển ra ngoài trung tâm mua nhà" href="//lg1.logging.admicro.vn/nd?nid=20200107165507064&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fo-nhiem-bui-min-o-ha-noi-nguoi-dan-chuyen-ra-ngoai-trung-tam-mua-nha-20200107165507064.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Ô nhiễm bụi mịn ở Hà Nội, người dân chuyển ra ngoài trung tâm mua nhà</span></a></li>

                        <li data-id="20200107204641658"><span class="time timeliveheader" data-month="01" data-date="07">20:46</span><span class="border_split" style="height: 25px;"></span><a title="Bị CSGT dừng xe vì không đội mũ bảo hiểm, thanh niên người nước ngoài mang đàn ra ngồi hát" href="//lg1.logging.admicro.vn/nd?nid=20200107204641658&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fbi-csgt-dung-xe-vi-khong-doi-mu-bao-hiem-thanh-nien-nguoi-nuoc-ngoai-mang-dan-ra-ngoi-hat-20200107204641658.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Bị CSGT dừng xe vì không đội mũ bảo hiểm, thanh niên người nước ngoài mang đàn ra ngồi hát</span></a></li>

                        <li data-id="20200107112316611"><span class="time timeliveheader" data-month="01" data-date="07">20:24</span><span class="border_split" style="height: 10px;"></span><a title="Forbes: 5 sự thật về AI mà tất cả chúng ta nhất định phải biết!" href="//lg1.logging.admicro.vn/nd?nid=20200107112316611&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fforbes-5-su-that-ve-ai-ma-tat-ca-chung-ta-nhat-dinh-phai-biet-20200107112316611.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Forbes: 5 sự thật về AI mà tất cả chúng ta nhất định phải biết!</span></a></li>

                        <li data-id="2020010717230308"><span class="time timeliveheader" data-month="01" data-date="07">20:12</span><span class="border_split" style="height: 25px;"></span><a title="Lật tẩy chiêu trò cho vay lãi nặng &quot;trá hình&quot; với lãi suất lên đến 360%/năm" href="//lg1.logging.admicro.vn/nd?nid=2020010717230308&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Flat-tay-chieu-tro-cho-vay-lai-nang-tra-hinh-voi-lai-suat-len-den-360-nam-2020010717230308.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Lật tẩy chiêu trò cho vay lãi nặng "trá hình" với lãi suất lên đến 360%/năm</span></a></li>

                        <li data-id="20200107200653892"><span class="time timeliveheader" data-month="01" data-date="07">20:07</span><span class="border_split" style="height: 10px;"></span><a title="Bộ Quốc phòng điều động, bổ nhiệm nhân sự Quân khu 2" href="//lg1.logging.admicro.vn/nd?nid=20200107200653892&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fbo-quoc-phong-dieu-dong-bo-nhiem-nhan-su-quan-khu-2-20200107200653892.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Bộ Quốc phòng điều động, bổ nhiệm nhân sự Quân khu 2</span></a></li>

                        <li data-id="20200107173146299"><span class="time timeliveheader" data-month="01" data-date="07">20:04</span><span class="border_split" style="height: 25px;"></span><a title="Thủ tướng 34 tuổi của Phần Lan đề xuất tuần làm việc 4 ngày, ngày làm 6 tiếng" href="//lg1.logging.admicro.vn/nd?nid=20200107173146299&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fthu-tuong-34-tuoi-cua-phan-lan-de-xuat-tuan-lam-viec-4-ngay-ngay-lam-6-tieng-20200107173146299.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Thủ tướng 34 tuổi của Phần Lan đề xuất tuần làm việc 4 ngày, ngày làm 6 tiếng</span></a></li>

                        <li data-id="20200106142621533"><span class="time timeliveheader" data-month="01" data-date="07">20:02</span><span class="border_split" style="height: 41px;"></span><a title="3 nữ tướng của 3 hãng công nghệ nổi tiếng Lyft, Google và Facebook tiết lộ chiến thuật giữ vững năng suất làm việc hiệu quả trong năm mới: Thời gian chính là yếu tố tiên quyết!" href="//lg1.logging.admicro.vn/nd?nid=20200106142621533&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2F3-nu-tuong-cua-3-hang-cong-nghe-noi-tieng-lyft-google-va-facebook-tiet-lo-chien-thuat-giu-vung-nang-suat-lam-viec-hieu-qua-trong-nam-moi-thoi-gian-chinh-la-yeu-to-tien-quyet-20200106142621533.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">3 nữ tướng của 3 hãng công nghệ nổi tiếng Lyft, Google và Facebook tiết lộ chiến thuật giữ vững năng suất làm việc hiệu quả trong năm mới: Thời gian chính là yếu tố tiên quyết!</span></a></li>

                        <li data-id="2020010717160547"><span class="time timeliveheader" data-month="01" data-date="07">20:02</span><span class="border_split" style="height: 25px;"></span><a title="Biểu hiện, nghề nghiệp phù hợp với 9 loại trí thông minh và những nhân vật nổi tiếng điển hình, ai cũng nên tìm hiểu ngay!" href="//lg1.logging.admicro.vn/nd?nid=2020010717160547&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fbieu-hien-nghe-nghiep-phu-hop-voi-9-loai-tri-thong-minh-va-nhung-nhan-vat-noi-tieng-dien-hinh-ai-cung-nen-tim-hieu-ngay-2020010717160547.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Biểu hiện, nghề nghiệp phù hợp với 9 loại trí thông minh và những nhân vật nổi tiếng điển hình, ai cũng nên tìm hiểu ngay!</span></a></li>

                        <li data-id="20200107172006752"><span class="time timeliveheader" data-month="01" data-date="07">19:55</span><span class="border_split" style="height: 25px;"></span><a title="Nữ hoàng Anh lại tuyển dụng: Tìm trợ lý phục vụ không cần kinh nghiệm, bao ăn ở trong cung điện, lương “sương sương” hơn 500 triệu" href="//lg1.logging.admicro.vn/nd?nid=20200107172006752&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fnu-hoang-anh-lai-tuyen-dung-tim-tro-ly-phuc-vu-khong-can-kinh-nghiem-bao-an-o-trong-cung-dien-luong-suong-suong-hon-500-trieu-20200107172006752.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Nữ hoàng Anh lại tuyển dụng: Tìm trợ lý phục vụ không cần kinh nghiệm, bao ăn ở trong cung điện, lương “sương sương” hơn 500 triệu</span></a></li>

                        <li data-id="20200107173100455"><span class="time timeliveheader" data-month="01" data-date="07">19:52</span><span class="border_split" style="height: 25px;"></span><a title="&quot;Nước trong thì không có cá, người tốt quá thì không ai chơi&quot;: Bài học về giới hạn cho tuýp người hào phóng" href="//lg1.logging.admicro.vn/nd?nid=20200107173100455&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fnuoc-trong-thi-khong-co-ca-nguoi-tot-qua-thi-khong-ai-choi-bai-hoc-ve-gioi-han-cho-tuyp-nguoi-hao-phong-20200107173100455.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">"Nước trong thì không có cá, người tốt quá thì không ai chơi": Bài học về giới hạn cho tuýp người hào phóng</span></a></li>

                        <li data-id="20200107093340002"><span class="time timeliveheader" data-month="01" data-date="07">19:36</span><span class="border_split" style="height: 10px;"></span><a title="Gỡ khó cho đầu tàu kinh tế" href="//lg1.logging.admicro.vn/nd?nid=20200107093340002&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fgo-kho-cho-dau-tau-kinh-te-20200107093340002.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Gỡ khó cho đầu tàu kinh tế</span></a></li>

                        <li data-id="20200107095714736"><span class="time timeliveheader" data-month="01" data-date="07">19:36</span><span class="border_split" style="height: 25px;"></span><a title="Cơ quan Kinh tế Đài Loan nói gì về việc đầu tư vào lĩnh vực sản xuất hàng công nghệ cao ở Việt Nam?" href="//lg1.logging.admicro.vn/nd?nid=20200107095714736&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fco-quan-kinh-te-dai-loan-noi-gi-ve-viec-dau-tu-vao-linh-vuc-san-xuat-hang-cong-nghe-cao-o-viet-nam-20200107095714736.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Cơ quan Kinh tế Đài Loan nói gì về việc đầu tư vào lĩnh vực sản xuất hàng công nghệ cao ở Việt Nam?</span></a></li>

                        <li data-id="20200107161703689"><span class="time timeliveheader" data-month="01" data-date="07">19:34</span><span class="border_split" style="height: 10px;"></span><a title="&quot;Nói hàng không tăng trưởng nóng là chưa phù hợp&quot;" href="//lg1.logging.admicro.vn/nd?nid=20200107161703689&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fnoi-hang-khong-tang-truong-nong-la-chua-phu-hop-20200107161703689.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">"Nói hàng không tăng trưởng nóng là chưa phù hợp"</span></a></li>

                        <li data-id="2020010717424147"><span class="time timeliveheader" data-month="01" data-date="07">17:42</span><span class="border_split" style="height: 10px;"></span><a title="NHNN chấp thuận cho Ngân hàng SCB chuyển trụ sở chính về quận 1" href="//lg1.logging.admicro.vn/nd?nid=2020010717424147&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fnhnn-chap-thuan-cho-ngan-hang-scb-chuyen-tru-so-chinh-ve-toa-nha-bitexco-2020010717424147.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">NHNN chấp thuận cho Ngân hàng SCB chuyển trụ sở chính về quận 1</span></a></li>

                        <li data-id="20200107140931095"><span class="time timeliveheader" data-month="01" data-date="07">17:42</span><span class="border_split" style="height: 10px;"></span><a title="Ngôi nhà hoa cúc ở Miền Trung được báo Mỹ khen hết lời" href="//lg1.logging.admicro.vn/nd?nid=20200107140931095&amp;zid=4&amp;dmn=http%3A%2F%2Fcafef.vn&amp;cov=1&amp;url=%2F&amp;re=http%3A%2F%2Fcafef.vn%2Fngoi-nha-hoa-cuc-o-mien-trung-duoc-bao-my-khen-het-loi-20200107140931095.chn&amp;covid=0&amp;gid=5560471001953472929&amp;ext="><span class="inner">Ngôi nhà hoa cúc ở Miền Trung được báo Mỹ khen hết lời</span></a></li>

            </ul>
        </div><div class="slimScrollBar" style="background: rgb(198, 198, 198); width: 18px; position: absolute; top: 0px; opacity: 0.7; display: block; border-radius: 7px; z-index: 99; right: 1px; height: 32.5101px;"></div><div class="slimScrollRail" style="width: 18px; height: 100%; position: absolute; top: 0px; display: block; border-radius: 7px; background: rgb(219, 223, 229); opacity: 0.2; z-index: 90; right: 1px;"></div></div>
    </div>
</div>
<script>
    (runinit = window.runinit || []).push(function () {
        setTimeout(function () {
            if (typeof sendLogCafefScroll === "function") {
                sendLogCafefScroll('listNewHeader', 155);
            }
        }, 1000);
    });
</script>



<div class="bieudo_header">
    <div class="bieudo1" style="display: block;">
        <p class="index_ck up">VN-Index:
            <b class="idx_1" style="">958.88</b> <span class="idc_1" style="">+3.09</span> <span class="idp_1" style="">+0.32%</span>
        </p>
        <p class="gia_ck">GTGD: <span class="idv_1" style="">2,072.2</span> tỷ VNĐ</p>
        <div id="headerchart1" class="img_bieudo" style="background: url(&quot;http://s.cafef.vn/chartindex/merge/cafefchart3.png?d=202017&quot;) 0px 0px;"></div>
    </div>
    <div class="bieudo2" style="display: block;">
        <p class="index_ck up">HNX-Index:
            <b class="idx_2" style="">101.42</b> <span class="idc_2" style="">+0.18</span> <span class="idp_2" style="">+0.18%</span>
        </p>
        <p class="gia_ck">GTGD: <span class="idv_2" style="">205.6</span> tỷ VNĐ</p>
        <div id="headerchart2" class="img_bieudo" style="background: url(&quot;http://s.cafef.vn/chartindex/merge/cafefchart3.png?d=202017&quot;) -140px 0px;"></div>
    </div>
</div>

<script type="text/javascript">
    var currentTime = parseFloat('212045');
</script>

        </div>
    </div>
    <div class="clearfix"></div>
    <div class="menucategory menuheader clearfix" id="menu_wrap" style="position: fixed; top: 0px; left: 0px; margin-top: 0px;">
        <div class="wp1040 relative">
            <ul>
                <li id="menu" class="acvmenu bt_home active"><a href="/" title="Trang chủ" class="sprite"></a></li>
                <li id="menu-thoi-su" class="acvmenu li_left "><a href="/thoi-su.chn" title="THỜI SỰ">THỜI SỰ</a></li>
                <li id="menu-thi-truong-chung-khoan" class="acvmenu "><a href="/thi-truong-chung-khoan.chn" title="CHỨNG KHOÁN">CHỨNG KHOÁN</a></li>
                <li id="menu-bat-dong-san" class="acvmenu "><a href="/bat-dong-san.chn" title="BẤT ĐỘNG SẢN">BẤT ĐỘNG SẢN</a></li>
                <li id="menu-doanh-nghiep" class="acvmenu "><a href="/doanh-nghiep.chn" title="DOANH NGHIỆP">DOANH NGHIỆP</a></li>
                <li id="menu-tai-chinh-ngan-hang" class="acvmenu "><a href="/tai-chinh-ngan-hang.chn" title="NGÂN HÀNG">NGÂN HÀNG</a></li>
                <li id="menu-tai-chinh-quoc-te" class="acvmenu "><a href="/tai-chinh-quoc-te.chn" title="TÀI CHÍNH QUỐC TẾ">TÀI CHÍNH QUỐC TẾ</a></li>
                <li id="menu-vi-mo-dau-tu" class="acvmenu "><a href="/vi-mo-dau-tu.chn" title="VĨ MÔ">VĨ MÔ</a></li>
                <li id="menu-song" class="acvmenu "><a href="/song.chn" title="SỐNG">SỐNG</a></li>
                <li id="menu-hang-hoa-nguyen-lieu" class="acvmenu "><a href="/thi-truong.chn" title="THỊ TRƯỜNG">THỊ TRƯỜNG</a></li>
                <li class="cut icon_menu_right"><a href="javascript:void(0);" class="bt_cut" rel="nofollow" title="">
                    <span class="ei-line1"></span>
                    <span class="ei-line2"></span>
                    <span class="ei-line3"></span>
                </a>
                    <div class="menu-ext">
                        <div class="inner clearfix">
                            <table class="sub-cat">
                                <tbody><tr>
                                    <td>
                                        <label class="th font2b">Tin tức</label>
                                        <a href="/thoi-su.chn" title="thời sự">Thời sự</a>
                                        <a href="/doanh-nghiep.chn" title="doanh nghiệp">Doanh nghiệp</a>
                                        <a href="/vi-mo-dau-tu.chn" title="kinh tế vĩ mô">Kinh tế vĩ mô</a>
                                    </td>
                                    <td>
                                        <label class="th font2b">Tài chính - Chứng khoán</label>
                                        <a href="/thi-truong-chung-khoan.chn" title="chứng khoáng">Chứng khoán</a>
                                        <a href="/tai-chinh-ngan-hang.chn" title="tài chính ngân hàng">Tài chính ngân hàng</a>
                                        <a href="/tai-chinh-quoc-te.chn" title="tài chính quốc tế">Tài chính quốc tế</a>
                                    </td>
                                    <td>
                                        <label class="th font2b">Bất động sản</label>
                                        <a href="/bat-dong-san.chn" title="tin tức">Tin tức</a>
                                        <a href="/du-an.chn" title="dự án">Dự án</a>
                                        <a href="/ban-do-du-an.chn" title="bản đồ dự án">Bản đồ dự án</a>
                                    </td>
                                    <td class="hide1024">
                                        <label class="th font2b">Khác</label>
                                        <a href="/hang-hoa-nguyen-lieu.chn" title="hàng hóa nguyên liệu">Hàng hóa nguyên liệu</a>
                                        <a href="/song.chn" title="sống">Sống</a>
                                        <a href="/videos.chn" title="video">Video</a>
                                    </td>
                                </tr>
                            </tbody></table>

        <div class="threads">
            <label class="label font2b">CHỦ ĐỀ NÓNG</label>
            <ul class=" list clearfix">
                <i class="shadow"></i>

        <li class="first"><a href="/su-kien/734-ket-qua-kinh-doanh-2019.chn" title="KẾT QUẢ KINH DOANH 2019"><i class="ico-idx5"></i>KẾT QUẢ KINH DOANH 2019</a></li>

        <li><a href="/su-kien/733-nghe-ngan-hang.chn" title="NGHỀ NGÂN HÀNG"><i class="ico-idx5"></i>NGHỀ NGÂN HÀNG</a></li>

        <li><a href="/su-kien/732-vi-mot-viet-nam-hung-cuong.chn" title="Vì một Việt Nam hùng cường"><i class="ico-idx5"></i>Vì một Việt Nam hùng cường</a></li>

        </ul>
       </div>


                        </div>
                        <div class="expand">
                            <a href="/nhom-chu-de/emagazine.chn" class="textExpand">Magazine</a>
                        </div>
                    </div>
                </li>
                <li class="menucategory_right"><a href="http://s.cafef.vn/top/ceo.chn" target="_blank" title="Top 200">Top 200</a></li>
                <li class="menucategory_right"><a href="http://s.cafef.vn/du-lieu.chn" target="_blank" title="Dữ liệu">Dữ liệu</a></li>
            </ul>
        </div>
    </div>
</div>
