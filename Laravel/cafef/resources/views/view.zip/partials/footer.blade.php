    <div class="clearfix"></div>

    <div data-check-position="cf_home-position_b5"></div>
    <div class="loadboxvideohome" data-marked-zoneid="cf_home_b6"></div>


    <script>
        (runinit = window.runinit || []).push(function () {
            FomartExtendListNews.content = ".listchungkhoannew";
            FomartExtendListNews.init();
        });
    </script>

        <div class="clearfix"></div>


<div id="adm_sticky_footer"></div>
<div class="footer hide-loading">

        <div class="wp1040">


<div class="clr mgt15">
    <div id="admzone100"></div>
    <script>
        admicroAD.unit.push(function () { admicroAD.show('admzone100') });
    </script>
</div>
        </div>


    <div class="menucategory clearfix menufooter">
        <div class="wp1040">
            <ul>
                <li class="bt_home active"><a href="/" title="Trang chủ" class="sprite"></a></li>
                <li class="li_left"><a href="/thoi-su.chn" title="THỜI SỰ">THỜI SỰ</a></li>
                <li><a href="/thi-truong-chung-khoan.chn" title="CHỨNG KHOÁN">CHỨNG KHOÁN</a></li>
                <li><a href="/bat-dong-san.chn" title="BẤT ĐỘNG SẢN">BẤT ĐỘNG SẢN</a></li>
                <li><a href="/doanh-nghiep.chn" title="DOANH NGHIỆP">DOANH NGHIỆP</a></li>
                <li><a href="/tai-chinh-ngan-hang.chn" title="NGÂN HÀNG">NGÂN HÀNG</a></li>
                <li><a href="/tai-chinh-quoc-te.chn" title="TÀI CHÍNH QUỐC TẾ">TÀI CHÍNH QUỐC TẾ</a></li>
                <li><a href="/vi-mo-dau-tu.chn" title="VĨ MÔ">VĨ MÔ</a></li>
                <li><a href="/song.chn" title="Sống">SỐNG</a></li>
                <li><a href="/thi-truong.chn" title="Thị trường">THỊ TRƯỜNG</a></li>

                <li class="menucategory_right"><a href="http://s.cafef.vn/du-lieu.chn" target="_blank" title="Dữ liệu">Dữ liệu</a></li>
                <li class="menucategory_right"><a href="http://s.cafef.vn/top/ceo.chn" target="_blank" title="Top 200">Top 200</a></li>
            </ul>
        </div>
    </div>
    <div class="info clearfix">
        <div class="wp1040">
            <div class="left">
                <p><b>Ban biên tập CafeF</b></p>
                <p>Địa chỉ: Tầng 21 Tòa nhà Center Building. Số 1 Nguyễn Huy Tưởng, Thanh Xuân, Hà Nội.</p>
                <p>Điện thoại: 024 7309 5555 Máy lẻ 292. Fax: 024-39744082</p>
                <p>Email: info@cafef.vn | Hotline: 0926 864 344</p>
                <p>Chịu trách nhiệm nội dung: Ông Nguyễn Thế Tân</p>


            </div>
            <div class="center">
                <p><b>Liên hệ quảng cáo</b></p>
                <p>Hotline: 0942 86 11 33</p>
                <p>Email: doanhnghiep@admicro.vn</p>

            </div>
            <div class="right">
                <p>
                    <a href="http://www.vccorp.vn/" target="_blank" title="Công ty Cổ phần VCCorp" class="" rel="nofollow">
                        <img src="https://vccorp.mediacdn.vn/vccorp-s.png" alt="Công ty Cổ phần VCCorp" />
                    </a>
                </p>
                <p><b>© Copyright 2007 - 2020 - Công ty Cổ phần VCCorp.</b></p>
                <p>Giấy phép thiết lập trang thông tin điện tử tổng hợp trên mạng số 2216/GP-TTĐT do Sở Thông tin và Truyền thông Hà Nội cấp ngày 10 tháng 4 năm 2019.</p>
                <p></p>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="chinhsach">
        <div class="wp1040">
            <a href="javascript:void(0)" onclick="SharePolicy();return false;" rel="nofollow" title="Thỏa thuận chia sẻ nội dung">Thỏa thuận chia sẻ nội dung</a>
            <a href="http://adi.admicro.vn/chinh-sach/chinh_sach_bao_mat.pdf" target="_blank" rel="nofollow" title="Chính sách bảo mật">Chính sách bảo mật</a>
            <p>Ghi rõ nguồn "CafeF" khi phát hành lại thông tin từ kênh thông tin này.</p>
        </div>
    </div>
</div>



        </div>
    </form>

            <div id="container-bottom-right">
                <div class="box-title">
                    <div class="sprite icon-wrap">
                    </div>
                    <div class="close-wrap">
                        <input type="button" class="close" value="x" id="btnClosed" />
                    </div>
                </div>
                <div class="box-content">
                </div>
            </div>
    <div id="VID_taskbar" class="VID_taskbar" rel="09e776cfdcf813daf939719ded62d915"></div>

    <div id="back-to-top" class="Cafef-scrolltop"><span>Trở lên trên</span></div>
    <div id="jscontrol">



<script type="text/javascript" src="https://adminplayer.sohatv.vn/resource/init-script/playerInitScript.js"></script>



    <script src="http://cafefcdn.com/web_js/jshome.min.20191128v1.js" type="text/javascript" async onload="loadBoxChungKhoan()"></script>
    <script>
        document.getElementById("menu").classList.add("active");
        (runinit = window.runinit || []).push(function () {
            loadJsAsync('http://cafefcdn.com/web_js/common.min.20181218v1.js', function () { });
        });
        (runinit = window.runinit || []).push(function () {
            loadJsHome.init();
            slimScrollBoxTinMoi();
            prNews.homeList();
            equalBoxHeight('.boxexamination','.news-list li');
        });
    </script>







        </div>

    <script src="//media1.admicro.vn/js_boxapp/tagsponsorz_40403.js" async></script>
