<div class="news_left">


    <div data-check-position="cf_home-position_focus"></div>
    <div class="top_noibat clearfix" data-marked-zoneid="cf_home_focus">
        <div class="top_noibat_row1 clearfix">
            <h2><a href="/thi-phan-moi-gioi-chung-khoan-5-ctck-lon-nhat-viet-nam-mat-dan-thi-phan-vao-tay-nhung-dai-gia-moi-noi-20200107104945252.chn" title="Thị phần của 5 công ty chứng khoán lớn nhất Việt Nam sụt giảm nghiêm trọng trước sự đổ bộ của công ty ngoại và áp lực zero fee">Thị phần của 5 công ty chứng khoán lớn nhất Việt Nam sụt giảm nghiêm trọng trước sự đổ bộ của công ty ngoại và áp lực zero fee</a></h2>
            <div class="bghltop clearfix">
                <div class="left">
                    <strong class="sapo">Tổng thị phần top 5 CTCK top đầu trong năm 2019 chỉ còn 44,27%, giảm mạnh so với con số 53,83% trong năm trước.</strong>

                </div>
                <div class="right">
                    <a class="avatar " href="/thi-phan-moi-gioi-chung-khoan-5-ctck-lon-nhat-viet-nam-mat-dan-thi-phan-vao-tay-nhung-dai-gia-moi-noi-20200107104945252.chn" title="Thị phần của 5 công ty chứng khoán lớn nhất Việt Nam sụt giảm nghiêm trọng trước sự đổ bộ của công ty ngoại và áp lực zero fee"><img src="http://cafefcdn.com/zoom/370_230/2020/1/7/annetaristhefightforasmallersliceofpie-1515473021914-15470238175381358852465-crop-15470238246421869392592-1578368748461149232970-crop-1578368754289830679295.jpg" alt="Thị phần của 5 công ty chứng khoán lớn nhất Việt Nam sụt giảm nghiêm trọng trước sự đổ bộ của công ty ngoại và áp lực zero fee" title="Thị phần của 5 công ty chứng khoán lớn nhất Việt Nam sụt giảm nghiêm trọng trước sự đổ bộ của công ty ngoại và áp lực zero fee"></a>
                </div>
            </div>
        </div>
        <div class="top_noibat_row2 mgt20">
            <ul>
                <li class="big "><a class="avatar " href="/ket-thuc-nam-2019-cac-ngan-hang-dua-bao-lai-lon-20200107150857064.chn" title="Kết thúc năm 2019, các ngân hàng đua báo lãi lớn"><img src="http://cafefcdn.com/zoom/230_143/2020/1/7/lgo-15783910183831073891433-crop-1578391023843227594606.jpg" alt="Kết thúc năm 2019, các ngân hàng đua báo lãi lớn" title="Kết thúc năm 2019, các ngân hàng đua báo lãi lớn"></a><h2><a href="/ket-thuc-nam-2019-cac-ngan-hang-dua-bao-lai-lon-20200107150857064.chn" title="Kết thúc năm 2019, các ngân hàng đua báo lãi lớn">Kết thúc năm 2019, các ngân hàng đua báo lãi lớn</a></h2></li><li class="big "><a class="avatar " href="/hinh-anh-hang-loat-cua-hang-vien-thong-a-dong-cua-dau-an-cua-anh-ca-nganh-ban-le-sap-bien-mat-20200107090303127.chn" title="Hình ảnh hàng loạt cửa hàng Viễn Thông A đóng cửa, dấu ấn của &quot;anh cả&quot; ngành bán lẻ sắp biến mất"><img src="http://cafefcdn.com/zoom/230_143/2020/1/7/ictnews20200106104845-15783624862521094884287-crop-15783624981751866968123.jpg" alt="Hình ảnh hàng loạt cửa hàng Viễn Thông A đóng cửa, dấu ấn của &quot;anh cả&quot; ngành bán lẻ sắp biến mất" title="Hình ảnh hàng loạt cửa hàng Viễn Thông A đóng cửa, dấu ấn của &quot;anh cả&quot; ngành bán lẻ sắp biến mất"></a><h2><a href="/hinh-anh-hang-loat-cua-hang-vien-thong-a-dong-cua-dau-an-cua-anh-ca-nganh-ban-le-sap-bien-mat-20200107090303127.chn" title="Hình ảnh hàng loạt cửa hàng Viễn Thông A đóng cửa, dấu ấn của " anh="" cả"="" ngành="" bán="" lẻ="" sắp="" biến="" mất"="">Hình ảnh hàng loạt cửa hàng Viễn Thông A đóng cửa, dấu ấn của "anh cả" ngành bán lẻ sắp biến mất</a></h2></li><li class="big "><a class="avatar " href="/vua-tang-nhu-chua-tung-co-ngay-hom-qua-hang-loat-co-phieu-lai-dua-nhau-giam-gia-2020010709532308.chn" title="Tiền bắt đầu quay lại chứng khoán, hàng loạt cổ phiếu tăng giá trở lại"><img src="http://cafefcdn.com/zoom/230_143/2019/12/30/ck11-157769122104743059848-crop-1578371399010685681421.jpg" alt="Tiền bắt đầu quay lại chứng khoán, hàng loạt cổ phiếu tăng giá trở lại" title="Tiền bắt đầu quay lại chứng khoán, hàng loạt cổ phiếu tăng giá trở lại"></a><h2><a href="/vua-tang-nhu-chua-tung-co-ngay-hom-qua-hang-loat-co-phieu-lai-dua-nhau-giam-gia-2020010709532308.chn" title="Tiền bắt đầu quay lại chứng khoán, hàng loạt cổ phiếu tăng giá trở lại">Tiền bắt đầu quay lại chứng khoán, hàng loạt cổ phiếu tăng giá trở lại</a></h2></li>
                <script> var ItemHlThird = [{"Avatar":"http://cafefcdn.com/zoom/260_162/2020/1/7/ictnews20200106104845-15783624862521094884287-crop-15783624981751866968123.jpg", "Title":"H&#236;nh ảnh h&#224;ng loạt cửa h&#224;ng Viễn Th&#244;ng A đ&#243;ng cửa, dấu ấn của &quot;anh cả&quot; ng&#224;nh b&#225;n lẻ sắp biến mất", "Sapo":"H&#224;ng loạt cửa h&#224;ng Viễn Th&#244;ng A vang b&#243;ng một thời, toạ lạc tại c&#225;c vị tr&#237; đắc địa, đều đ&#243;ng cửa im ỉm trong những ng&#224;y cuối năm.", "Url":"/hinh-anh-hang-loat-cua-hang-vien-thong-a-dong-cua-dau-an-cua-anh-ca-nganh-ban-le-sap-bien-mat-20200107090303127.chn", "Date":"2020-01-07T09:03:12", "CatName":"Doanh nghiệp", "CatUrl":"doanh-nghiep.chn"}]</script>

            </ul>
        </div>

    </div>
    <div class="light-box-bounder">
        <div class="light-box-content">
            <div class="light-box loading">
            </div>
        </div>
        <div class="close-wrap">
            <div class="close">
                <div class="close-1"></div>
                <div class="close-2"></div>
            </div>
        </div>
    </div>

    <script>
        (runinit = window.runinit || []).push(function () {
            prNews.homeFocus();
        });
    </script>

                        <div class="clearfix"></div>

    <div class="top_event clearfix">
        <ul>

                    <li><span>»</span><a href="/su-kien/734-ket-qua-kinh-doanh-2019.chn" title="KẾT QUẢ KINH DOANH 2019">KẾT QUẢ KINH DOANH 2019</a></li>

                    <li><span>»</span><a href="/su-kien/732-vi-mot-viet-nam-hung-cuong.chn" title="Vì một Việt Nam hùng cường">Vì một Việt Nam hùng cường</a></li>

                    <li><span>»</span><a href="/su-kien/731-cocobay-da-nang-vo-tran.chn" title="Cocobay Đà Nẵng vỡ trận">Cocobay Đà Nẵng vỡ trận</a></li>

                    <li><span>»</span><a href="/su-kien/727-goc-kinh-te-hoc.chn" title="Góc Kinh tế học">Góc Kinh tế học</a></li>

                    <li><span>»</span><a href="/su-kien/725-loi-nhuan-ngan-hang-quy-32019.chn" title="Lợi nhuận ngân hàng quý 3/2019">Lợi nhuận ngân hàng quý 3/2019</a></li>

        </ul>
    </div>



    <div class="mgt10">
     <div id="admzone101"><div id="zone-101"><div id="share-jtgyrgw3"><div id="placement-k01sxzy1" revenue="pb"><div id="banner-101-k01sy0oe" style="min-height: 10px; min-width: 10px;"><div id="slot-1-101-k01sy0oe"><div></div></div></div></div></div> </div></div>
        <script>
            admicroAD.unit.push(function () { admicroAD.show('admzone101') });
        </script>
        </div>
                        <div class="top5_news">
                            <div class="magazine-and-investors clearfix">


    <div class="home-box-magazine">


                <div class="home-box-magazine-news clearfix" style="height: 271px;">

                    <a class="avatar " href="/cha-de-cua-giong-gao-ngon-nhat-the-gioi-ban-dau-minh-tinh-lam-choi-thoi-20200104093156095.chn" title="Kỹ sư Hồ Quang Cua - Cha đẻ của giống gạo ngon nhất thế giới: Ban đầu mình tính làm chơi thôi!"><img src="http://cafefcdn.com/zoom/330_205/2020/1/4/thumb-15781049383261167129027-crop-15781049458991707934778.png" alt="Kỹ sư Hồ Quang Cua - Cha đẻ của giống gạo ngon nhất thế giới: Ban đầu mình tính làm chơi thôi!" title="Kỹ sư Hồ Quang Cua - Cha đẻ của giống gạo ngon nhất thế giới: Ban đầu mình tính làm chơi thôi!"></a>
                    <div class="home-box-magazine-news-info">
                        <h3>
                            <a title="Kỹ sư Hồ Quang Cua - Cha đẻ của giống gạo ngon nhất thế giới: Ban đầu mình tính làm chơi thôi!" href="/cha-de-cua-giong-gao-ngon-nhat-the-gioi-ban-dau-minh-tinh-lam-choi-thoi-20200104093156095.chn">
                                Kỹ sư Hồ Quang Cua - Cha đẻ của giống gạo ngon nhất thế giới: Ban đầu mình tính làm chơi thôi!
                                </a><a href="/nhom-chu-de/emagazine.chn" title="Nhóm chủ đề">

                                    <span class="home-box-magazine-top-label">Magazine
                                    </span>
                                </a>

                        </h3>
                    </div>
                </div>


                <div class="home-box-magazine-news clearfix" style="height: 271px;">
                     <div id="admzonejy0yoth5"><div id="zone-jy0yoth5"><div id="share-jy0youef"><div id="placement-jyb07ws7" revenue="cpm"><div id="banner-jy0yoth5-jyb07wso" style="min-height: 10px; min-width: 10px;"><div id="slot-1-jy0yoth5-jyb07wso"><div id="ssppagebid_3622"></div>
    <script>if (typeof(admsspPosition) == "undefined") {_admloadJs("//media1.admicro.vn/core/ssppage.js", function () {admsspPosition({sspid:3622,w:0,h:0, group: ""}); });} else {admsspPosition({sspid:3622,w:0,h:0, group: ""});}</script></div></div></div></div> </div></div>
                    <a class="avatar " href="/tai-san-cua-top-10-nguoi-giau-nhat-tren-thi-truong-chung-khoan-tiep-tuc-sinh-soi-nay-no-vuot-360000-ty-dong-20191231162525951.chn" title="Tài sản của Top 10 người giàu nhất trên thị trường chứng khoán tiếp tục sinh sôi nảy nở, vượt 360.000 tỷ đồng"><img src="http://cafefcdn.com/zoom/330_205/2019/12/31/cover-1577784133100667041441-crop-1577784143428893809703.jpg" alt="Tài sản của Top 10 người giàu nhất trên thị trường chứng khoán tiếp tục sinh sôi nảy nở, vượt 360.000 tỷ đồng" title="Tài sản của Top 10 người giàu nhất trên thị trường chứng khoán tiếp tục sinh sôi nảy nở, vượt 360.000 tỷ đồng"></a>
                    <div class="home-box-magazine-news-info">
                        <h3>
                            <a title="Tài sản của Top 10 người giàu nhất trên thị trường chứng khoán tiếp tục sinh sôi nảy nở, vượt 360.000 tỷ đồng" href="/tai-san-cua-top-10-nguoi-giau-nhat-tren-thi-truong-chung-khoan-tiep-tuc-sinh-soi-nay-no-vuot-360000-ty-dong-20191231162525951.chn">
                                Tài sản của Top 10 người giàu nhất trên thị trường chứng khoán tiếp tục sinh sôi nảy nở, vượt 360.000 tỷ đồng
                                </a><a href="/nhom-chu-de/emagazine.chn" title="Nhóm chủ đề">

                                    <span class="home-box-magazine-top-label">Magazine
                                    </span>
                                </a>

                        </h3>
                    </div>
                </div>

    </div>
    <script>
        admicroAD.unit.push(function () { admicroAD.show('admzonejy0yoth5') });
        (runinit = window.runinit || []).push(function () {
            box_magazine_and_investors_style();
        });
    </script>


    <div class="box-nha-dau-tu">
        <h2 class="title_box">Góc nhà đầu tư</h2>
        <div class="box-nha-dau-tu-content">
            <ul style="height: 522px;">

                        <li class="clearfix">

                            <a title="[Quy tắc đầu tư vàng] Chân dung cha đẻ dải Bollinger Bands: tỷ phú đầu tư huyền thoại ham học được cả thế giới kính nể" href="/quy-tac-dau-tu-vang-chan-dung-cha-de-dai-bollinger-bands-ty-phu-dau-tu-huyen-thoai-ham-hoc-duoc-ca-the-gioi-kinh-ne-20200105104215861.chn" class="bndt-item-title">
                                [Quy tắc đầu tư vàng] Chân dung cha đẻ dải Bollinger Bands: tỷ phú đầu tư huyền thoại ham học được cả thế giới kính nể
                            </a>
                        </li>

                        <li class="clearfix">

                            <a title="240 nhà đầu tư tranh mua cổ phần Nước sạch Bắc Giang" href="/240-nha-dau-tu-tranh-mua-co-phan-nuoc-sach-bac-giang-20200104193054955.chn" class="bndt-item-title">
                                240 nhà đầu tư tranh mua cổ phần Nước sạch Bắc Giang
                            </a>
                        </li>

                        <li class="clearfix">
                            <div id="admzonejy0yo7sx"></div>
                            <a title="Khối ngoại tiếp tục mua ròng trong tuần 30/12-3/1, tập trung gom HPG và VRE" href="/khoi-ngoai-tiep-tuc-mua-rong-trong-tuan-30-12-3-1-tap-trung-gom-hpg-va-vre-20200104192907049.chn" class="bndt-item-title">
                                Khối ngoại tiếp tục mua ròng trong tuần 30/12-3/1, tập trung gom HPG và VRE
                            </a>
                        </li>

                        <li class="clearfix">

                            <a title="Lọc dầu Dung Quất (BSR): Lãi ròng năm 2019 đạt 2.200 tỷ, lên kế hoạch 2020 khiêm tốn với 1.289 tỷ" href="/loc-dau-dung-quat-bsr-lai-rong-nam-2019-dat-2200-ty-len-ke-hoach-2020-khiem-ton-voi-1289-ty-20200104092955752.chn" class="bndt-item-title">
                                Lọc dầu Dung Quất (BSR): Lãi ròng năm 2019 đạt 2.200 tỷ, lên kế hoạch 2020 khiêm tốn với 1.289 tỷ
                            </a>
                        </li>

                        <li class="clearfix">

                            <a title="Những &quot;ông lớn&quot; lên sàn trong năm 2019 giờ ra sao?" href="/nhung-ong-lon-len-san-trong-nam-2019-gio-ra-sao-20191230094717873.chn" class="bndt-item-title">
                                Những "ông lớn" lên sàn trong năm 2019 giờ ra sao?
                            </a>
                        </li>

                        <li class="clearfix">

                            <a title="Saigonres (SGR) sẽ chuyển nhượng toàn bộ 70% cổ phần Đầu tư Bất động sản Lê Gia cho đối tác" href="/saigonres-sgr-se-chuyen-nhuong-toan-bo-70-co-phan-dau-tu-bat-dong-san-le-gia-cho-doi-tac-20200102175251732.chn" class="bndt-item-title">
                                Saigonres (SGR) sẽ chuyển nhượng toàn bộ 70% cổ phần Đầu tư Bất động sản Lê Gia cho đối tác
                            </a>
                        </li>

                        <li class="clearfix">

                            <a title="CII mua lại trước hạn 85,6 tỷ trái phiếu từ 9 cá nhân và 2 tổ chức, bao gồm Yeah1" href="/cii-mua-lai-truoc-han-856-ty-trai-phieu-tu-9-ca-nhan-va-2-to-chuc-bao-gom-yeah1-2020010218325317.chn" class="bndt-item-title">
                                CII mua lại trước hạn 85,6 tỷ trái phiếu từ 9 cá nhân và 2 tổ chức, bao gồm Yeah1
                            </a>
                        </li>

                        <li class="clearfix">

                            <a title="Người giàu cũng khóc 2019: Tài sản 2 sếp Masan-TCB bốc hơi 10.000 tỷ, Chủ tịch Yeah1 mất tới 82% vì sự cố YouTube" href="/nguoi-giau-cung-khoc-2019-tai-san-2-sep-masan-tcb-boc-hoi-10000-ty-ceo-yeah1-mat-toi-82-vi-su-co-youtube-20200102191342685.chn" class="bndt-item-title">
                                Người giàu cũng khóc 2019: Tài sản 2 sếp Masan-TCB bốc hơi 10.000 tỷ, Chủ tịch Yeah1 mất tới 82% vì sự cố YouTube
                            </a>
                        </li>

            </ul>
        </div>
    </div>
    <script>
        admicroAD.unit.push(function () { admicroAD.show('admzonejy0yo7sx') });
    </script>

                            </div>

                            <ul class="listchungkhoannew">



            <li class="tlitem clearfix top" data-newsid="20200107161456986">
                <a class="avatar " href="/thai-lan-dong-baht-khong-phai-la-vinh-tranh-bao-trong-cang-thang-my-iran-20200107161456986.chn" title="Thái Lan: Đồng Baht không phải là “vịnh tránh bão” trong căng thẳng Mỹ-Iran"><img src="http://cafefcdn.com/zoom/260_162/2020/photo1578388433886-1578388433959-crop-1578388441684725307313.jpg" alt="Thái Lan: Đồng Baht không phải là “vịnh tránh bão” trong căng thẳng Mỹ-Iran" title="Thái Lan: Đồng Baht không phải là “vịnh tránh bão” trong căng thẳng Mỹ-Iran"></a>
                <div class="knswli-right">
                    <h3><a href="/thai-lan-dong-baht-khong-phai-la-vinh-tranh-bao-trong-cang-thang-my-iran-20200107161456986.chn" title="Thái Lan: Đồng Baht không phải là “vịnh tránh bão” trong căng thẳng Mỹ-Iran">Thái Lan: Đồng Baht không phải là “vịnh tránh bão” trong căng thẳng Mỹ-Iran</a></h3>
                    <p class="time_cate ">
                        <a href="tai-chinh-quoc-te.chn" title="Tài chính quốc tế">Tài chính quốc tế</a>
                        <span class="gachngoai">-<span>
                            <span class="time" title="2020-01-07T21:05:10">1 giờ trước</span>
                    </span></span></p>
                    <p class="sapo">Thống đốc Ngân hàng Trung ương Thái Lan “dìm” đồng Baht trong bối cảnh đồng tiền này giữ đà tăng giá...</p>
                </div>
            </li>

            <li class="tlitem clearfix" data-newsid="20200107112719689">
                <a class="avatar " href="/o-nhiem-khong-khi-chang-nhung-tang-nguy-co-mac-ung-thu-tram-cam-ma-con-la-thu-pham-gay-nen-loai-benh-chi-em-nao-cung-so-20200107112719689.chn" title="Ô nhiễm không khí chẳng những tăng nguy cơ mắc ung thư, trầm cảm mà còn là thủ phạm gây nên loại bệnh chị em nào cũng sợ"><img src="http://cafefcdn.com/zoom/260_162/2020/1/7/5-1578303783652418644786-crop-1578303791131272184905-15783711683391518630905-crop-15783711717071611632618.jpg" alt="Ô nhiễm không khí chẳng những tăng nguy cơ mắc ung thư, trầm cảm mà còn là thủ phạm gây nên loại bệnh chị em nào cũng sợ" title="Ô nhiễm không khí chẳng những tăng nguy cơ mắc ung thư, trầm cảm mà còn là thủ phạm gây nên loại bệnh chị em nào cũng sợ"></a>
                <div class="knswli-right">
                    <h3><a href="/o-nhiem-khong-khi-chang-nhung-tang-nguy-co-mac-ung-thu-tram-cam-ma-con-la-thu-pham-gay-nen-loai-benh-chi-em-nao-cung-so-20200107112719689.chn" title="Ô nhiễm không khí chẳng những tăng nguy cơ mắc ung thư, trầm cảm mà còn là thủ phạm gây nên loại bệnh chị em nào cũng sợ">Ô nhiễm không khí chẳng những tăng nguy cơ mắc ung thư, trầm cảm mà còn là thủ phạm gây nên loại bệnh chị em nào cũng sợ</a></h3>
                    <p class="time_cate ">
                        <a href="song.chn" title="Sống">Sống</a>
                        <span class="gachngoai">-<span>
                            <span class="time" title="2020-01-07T21:03:25">1 giờ trước</span>
                    </span></span></p>
                    <p class="sapo">Những người sống trong bầu không khí ô nhiễm có tỷ lệ cao bị ung thư, trầm cảm... Nhưng như vậy vẫn chưa phải tất cả. Một nghiên cứu mới đã chỉ ra thêm 2 hiểm họa sức khỏe mà chị...</p>
                </div>
            </li>

            <li class="tlitem clearfix" data-newsid="20200107100357533">
                <a class="avatar " href="/chong-mat-voi-gia-vang-20200107100357533.chn" title="&quot;Chóng mặt&quot; với giá vàng"><img src="http://cafefcdn.com/zoom/260_162/2020/1/7/pnj258-2468-1483932878-15783660936981083661734-crop-1578366102043764278619.jpg" alt="&quot;Chóng mặt&quot; với giá vàng" title="&quot;Chóng mặt&quot; với giá vàng"></a>
                <div class="knswli-right">
                    <h3><a href="/chong-mat-voi-gia-vang-20200107100357533.chn" title="&quot;Chóng mặt&quot; với giá vàng">"Chóng mặt" với giá vàng</a></h3>
                    <p class="time_cate ">
                        <a href="tai-chinh-ngan-hang.chn" title="Tài chính - ngân hàng">Tài chính - ngân hàng</a>
                        <span class="gachngoai">-<span>
                            <span class="time" title="2020-01-07T10:04:07">12 giờ trước</span>
                    </span></span></p>
                    <p class="sapo">Vừa vượt mốc 44,5 triệu đồng/lượng chưa được bao lâu, giá vàng trong nước đã rớt mạnh về còn 43,8 triệu đồng/lượng.</p>
                </div>
            </li>

            <li class="tlitem clearfix" data-newsid="20200107141010986">
                <a class="avatar " href="/ngap-bui-min-vi-chay-rung-sydney-dang-tro-thanh-phong-thi-nghiem-cua-ca-the-gioi-de-nghien-cuu-ve-tac-hai-cua-khoi-bui-doi-voi-suc-khoe-20200107141010986.chn" title="Ngập bụi mịn vì cháy rừng, Sydney đang trở thành &quot;phòng thí nghiệm&quot; của cả thế giới"><img src="http://cafefcdn.com/zoom/260_162/2020/1/7/1200x800-1578380907471669289145-crop-1578380914340516822629.jpg" alt="Ngập bụi mịn vì cháy rừng, Sydney đang trở thành &quot;phòng thí nghiệm&quot; của cả thế giới" title="Ngập bụi mịn vì cháy rừng, Sydney đang trở thành &quot;phòng thí nghiệm&quot; của cả thế giới"></a>
                <div class="knswli-right">
                    <h3><a href="/ngap-bui-min-vi-chay-rung-sydney-dang-tro-thanh-phong-thi-nghiem-cua-ca-the-gioi-de-nghien-cuu-ve-tac-hai-cua-khoi-bui-doi-voi-suc-khoe-20200107141010986.chn" title="Ngập bụi mịn vì cháy rừng, Sydney đang trở thành &quot;phòng thí nghiệm&quot; của cả thế giới">Ngập bụi mịn vì cháy rừng, Sydney đang trở thành "phòng thí nghiệm" của cả thế giới</a></h3>
                    <p class="time_cate ">
                        <a href="tai-chinh-quoc-te.chn" title="Tài chính quốc tế">Tài chính quốc tế</a>
                        <span class="gachngoai">-<span>
                            <span class="time" title="2020-01-07T14:10:00">8 giờ trước</span>
                    </span></span></p>
                    <p class="sapo">Chất lượng không khí ở Sydney vốn rất tốt, vì thế các nhà nghiên cứu có thể dễ dàng xác định ô nhiễm không khí trên diện rộng gây ra những tác hại như thế nào đến sức khỏe con...</p>
                </div>
            </li>

            <li class="tlitem clearfix bottom" data-newsid="20200107154109627">
                <a class="avatar " href="/thu-tuong-quyet-dinh-thanh-lap-silicon-valley-da-nang-20200107154109627.chn" title="Thủ tướng quyết định thành lập &quot;Silicon Valley Đà Nẵng&quot;"><img src="http://cafefcdn.com/zoom/260_162/2020/1/7/vietnamconstructionvn-vi-20190314-h4-800x445-15783863978761295503918-crop-1578386407000531059805.jpg" alt="Thủ tướng quyết định thành lập &quot;Silicon Valley Đà Nẵng&quot;" title="Thủ tướng quyết định thành lập &quot;Silicon Valley Đà Nẵng&quot;"></a>
                <div class="knswli-right">
                    <h3><a href="/thu-tuong-quyet-dinh-thanh-lap-silicon-valley-da-nang-20200107154109627.chn" title="Thủ tướng quyết định thành lập &quot;Silicon Valley Đà Nẵng&quot;">Thủ tướng quyết định thành lập "Silicon Valley Đà Nẵng"</a></h3>
                    <p class="time_cate ">
                        <a href="vi-mo-dau-tu.chn" title="Kinh tế vĩ mô - Đầu tư ">Kinh tế vĩ mô - Đầu tư </a>
                        <span class="gachngoai">-<span>
                            <span class="time" title="2020-01-07T16:01:51">6 giờ trước</span>
                    </span></span></p>
                    <p class="sapo">Khu CNTT tập trung Đà Nẵng - giai đoạn 1 có diện tích 131 ha, thuộc địa bàn xã Hòa Liên, huyện Hòa Vang, do CTCP Phát triển Khu CNTT Đà Nẵng làm chủ đầu tư được kỳ  vọng sẽ trở...</p>
                </div>
            </li>





    <div id="admzone14092"><script>
    window.setTimeout(function(){
    var clientHeight = document.getElementById('admzone14092').clientHeight;
    if (clientHeight > 100) {
        document.getElementById("newsHlThird").style.display="none";
    }
     }, 1000);
    </script>

    <div id="slot1"><div id="zone-14092"><div id="share-jtgyrhft"><div id="placement-307394" revenue="cpm"><div id="banner-14092-507331" style="min-height: 10px; min-width: 10px;"><div id="slot-1-14092-507331"><div id="sponsorzone_472072"></div>
                            <script type="text/javascript">
                            var adm_location = "1";
                            try{
                              adm_location = Arf.detail.getValue('__R');
                              if(adm_location == "0"){adm_location = "1" }
                            }catch(e){}
                            Arf.utils.loadScript("//media1.admicro.vn/adn/sponsorzone_472072_"+adm_location+".js")

                            </script></div></div></div></div> </div></div>
    </div>
    <script>
        admicroAD.unit.push(function () { admicroAD.show('admzone14092') });
    </script>

                                <li class="clearfix top" id="newsHlThird"><a class="avatar " href="/hinh-anh-hang-loat-cua-hang-vien-thong-a-dong-cua-dau-an-cua-anh-ca-nganh-ban-le-sap-bien-mat-20200107090303127.chn" title="Hình ảnh hàng loạt cửa hàng Viễn Thông A đóng cửa, dấu ấn của &quot;anh cả&quot; ngành bán lẻ sắp biến mất"><img src="http://cafefcdn.com/zoom/260_162/2020/1/7/ictnews20200106104845-15783624862521094884287-crop-15783624981751866968123.jpg" alt="Hình ảnh hàng loạt cửa hàng Viễn Thông A đóng cửa, dấu ấn của &quot;anh cả&quot; ngành bán lẻ sắp biến mất" title="Hình ảnh hàng loạt cửa hàng Viễn Thông A đóng cửa, dấu ấn của &quot;anh cả&quot; ngành bán lẻ sắp biến mất"></a><div class="knswli-right"><h3><a href="/hinh-anh-hang-loat-cua-hang-vien-thong-a-dong-cua-dau-an-cua-anh-ca-nganh-ban-le-sap-bien-mat-20200107090303127.chn" title="Hình ảnh hàng loạt cửa hàng Viễn Thông A đóng cửa, dấu ấn của &quot;anh cả&quot; ngành bán lẻ sắp biến mất">Hình ảnh hàng loạt cửa hàng Viễn Thông A đóng cửa, dấu ấn của "anh cả" ngành bán lẻ sắp biến mất</a></h3><p class="time_cate "><a href="doanh-nghiep.chn" title="Doanh nghiệp">Doanh nghiệp</a> <span class="gachngoai">-<span> <span class="time" title="2020-01-07T09:03:12">13 giờ trước</span></span></span></p><p class="sapo">Hàng loạt cửa hàng Viễn Thông A vang bóng một thời, toạ lạc tại các vị trí đắc địa, đều đóng cửa im ỉm trong những ngày cuối năm.</p></div></li>
                            </ul>
                        </div>
                        <div class="top5_news mgt0">
                            <div data-check-position="cf_home-position_b1"></div>
                            <div class="kl-group-content clearfix" data-marked-zoneid="cf_home_b1">


    <div class="newdangchuy">
        <p class="title_box">ĐÁNG CHÚ Ý</p>
        <div class="kdsdsk-wrapper">
            <ul class="list-kdsdsk">

                        <li class="kdsdsk">

                            <a class="avatar clearfix" href="/smartphone-cua-ty-phu-pham-nhat-vuong-bat-ngo-tang-truong-chua-tung-co-sap-bang-apple-tai-viet-nam-2020010512231797.chn" title="Smartphone của tỷ phú Phạm Nhật Vượng bất ngờ tăng trưởng chưa từng có, sắp bằng Apple tại Việt Nam"><img src="http://cafefcdn.com/zoom/194_121/2020/1/5/photo-1-1578201660820562671687-crop-1578201702182902281453.jpg" alt="Smartphone của tỷ phú Phạm Nhật Vượng bất ngờ tăng trưởng chưa từng có, sắp bằng Apple tại Việt Nam" title="Smartphone của tỷ phú Phạm Nhật Vượng bất ngờ tăng trưởng chưa từng có, sắp bằng Apple tại Việt Nam"></a>
                            <h4>
                                <a title="Smartphone của tỷ phú Phạm Nhật Vượng bất ngờ tăng trưởng chưa từng có, sắp bằng Apple tại Việt Nam" href="/smartphone-cua-ty-phu-pham-nhat-vuong-bat-ngo-tang-truong-chua-tung-co-sap-bang-apple-tai-viet-nam-2020010512231797.chn">
                                    Smartphone của tỷ phú Phạm Nhật Vượng bất ngờ tăng trưởng chưa từng có, sắp bằng Apple tại Việt Nam
                                </a>
                            </h4>
                        </li>

                        <li class="kdsdsk">

                            <a class="avatar clearfix" href="/shark-hung-chung-ta-nen-tan-dung-thoi-gian-bang-cach-giam-bot-nhung-tro-vo-bo-nhu-game-tham-chi-ca-thoi-gian-ngu-20200105175752252.chn" title="Shark Hưng: Chúng ta nên tận dụng thời gian bằng cách giảm bớt những &quot;trò vô bổ&quot; như game, thậm chí cả thời gian ngủ!"><img src="http://cafefcdn.com/zoom/194_121/2020/photo1578221775374-1578221775758-crop-1578221862890469764896.jpg" alt="Shark Hưng: Chúng ta nên tận dụng thời gian bằng cách giảm bớt những &quot;trò vô bổ&quot; như game, thậm chí cả thời gian ngủ!" title="Shark Hưng: Chúng ta nên tận dụng thời gian bằng cách giảm bớt những &quot;trò vô bổ&quot; như game, thậm chí cả thời gian ngủ!"></a>
                            <h4>
                                <a title="Shark Hưng: Chúng ta nên tận dụng thời gian bằng cách giảm bớt những &quot;trò vô bổ&quot; như game, thậm chí cả thời gian ngủ!" href="/shark-hung-chung-ta-nen-tan-dung-thoi-gian-bang-cach-giam-bot-nhung-tro-vo-bo-nhu-game-tham-chi-ca-thoi-gian-ngu-20200105175752252.chn">
                                    Shark Hưng: Chúng ta nên tận dụng thời gian bằng cách giảm bớt những "trò vô bổ" như game, thậm chí cả thời gian ngủ!
                                </a>
                            </h4>
                        </li>

                        <li class="kdsdsk">

                            <a class="avatar clearfix" href="/nguoi-giau-cung-khoc-2019-tai-san-2-sep-masan-tcb-boc-hoi-10000-ty-ceo-yeah1-mat-toi-82-vi-su-co-youtube-20200102191342685.chn" title="Người giàu cũng khóc 2019: Tài sản 2 sếp Masan-TCB bốc hơi 10.000 tỷ, Chủ tịch Yeah1 mất tới 82% vì sự cố YouTube"><img src="http://cafefcdn.com/zoom/194_121/2020/1/3/mat-tien-2019-1578015980196588101210-crop-15780160028011910638407.jpg" alt="Người giàu cũng khóc 2019: Tài sản 2 sếp Masan-TCB bốc hơi 10.000 tỷ, Chủ tịch Yeah1 mất tới 82% vì sự cố YouTube" title="Người giàu cũng khóc 2019: Tài sản 2 sếp Masan-TCB bốc hơi 10.000 tỷ, Chủ tịch Yeah1 mất tới 82% vì sự cố YouTube"></a>
                            <h4>
                                <a title="Người giàu cũng khóc 2019: Tài sản 2 sếp Masan-TCB bốc hơi 10.000 tỷ, Chủ tịch Yeah1 mất tới 82% vì sự cố YouTube" href="/nguoi-giau-cung-khoc-2019-tai-san-2-sep-masan-tcb-boc-hoi-10000-ty-ceo-yeah1-mat-toi-82-vi-su-co-youtube-20200102191342685.chn">
                                    Người giàu cũng khóc 2019: Tài sản 2 sếp Masan-TCB bốc hơi 10.000 tỷ, Chủ tịch Yeah1 mất tới 82% vì sự cố YouTube
                                </a>
                            </h4>
                        </li>

                        <li class="kdsdsk">
                            <div id="admzonejy0ypqpg"><div id="zone-jy0ypqpg"><div id="share-jy0yprpw"><div id="placement-jyb09f90" revenue="cpm"><div id="banner-jy0ypqpg-jyb09f9f" style="min-height: 0px; min-width: 0px;"><div id="slot-1-jy0ypqpg-jyb09f9f"><div id="ssppagebid_3623"></div>
    <script>if (typeof(admsspPosition) == "undefined") {_admloadJs("//media1.admicro.vn/core/ssppage.js", function () {admsspPosition({sspid:3623,w:0,h:0, group: ""}); });} else {admsspPosition({sspid:3623,w:0,h:0, group: ""});}</script></div></div></div></div> </div></div>
                            <a class="avatar clearfix" href="/phi-hanh-gia-so-nho-nhat-the-gioi-bi-bo-roi-ngoai-vu-tru-suot-311-ngay-tro-ve-que-huong-thi-hay-tin-dat-nuoc-minh-da-khong-con-ton-tai-20200103225210095.chn" title="Phi hành gia số &quot;nhọ&quot; nhất thế giới: Bị bỏ rơi ngoài vũ trụ suốt 311 ngày, trở về quê hương thì hay tin đất nước mình đã không còn tồn tại"><img src="http://cafefcdn.com/zoom/194_121/2020/1/3/5cecf88715e9f9448b6db414-1578037741469-15780377414701646268526-crop-15780438292841194144542-157806669531639559568-crop-15780667036821327500761.jpg" alt="Phi hành gia số &quot;nhọ&quot; nhất thế giới: Bị bỏ rơi ngoài vũ trụ suốt 311 ngày, trở về quê hương thì hay tin đất nước mình đã không còn tồn tại" title="Phi hành gia số &quot;nhọ&quot; nhất thế giới: Bị bỏ rơi ngoài vũ trụ suốt 311 ngày, trở về quê hương thì hay tin đất nước mình đã không còn tồn tại"></a>
                            <h4>
                                <a title="Phi hành gia số &quot;nhọ&quot; nhất thế giới: Bị bỏ rơi ngoài vũ trụ suốt 311 ngày, trở về quê hương thì hay tin đất nước mình đã không còn tồn tại" href="/phi-hanh-gia-so-nho-nhat-the-gioi-bi-bo-roi-ngoai-vu-tru-suot-311-ngay-tro-ve-que-huong-thi-hay-tin-dat-nuoc-minh-da-khong-con-ton-tai-20200103225210095.chn">
                                    Phi hành gia số "nhọ" nhất thế giới: Bị bỏ rơi ngoài vũ trụ suốt 311 ngày, trở về quê hương thì hay tin đất nước mình đã không còn tồn tại
                                </a>
                            </h4>
                        </li>

            </ul>

        </div>
    </div>
    <script>
        admicroAD.unit.push(function () { admicroAD.show('admzonejy0ypqpg') });
    </script>

    <div class="higlight_box clearfix row1 box-goc-nhin-chuyen-gia" style="height: 533px;">
        <a href="/bai-viet-cua-cac-chuyen-gia.chn" title="góc nhìn chuyên gia">
            <p class="title_box">GÓC NHÌN CHUYÊN GIA</p>
        </a>
        <div class="chuyengia_box clearfix">
            <div class="chuyengia_bg clearfix">
                                <div class="chuyengian-quote">
                                    <span class="icon_quote sprite"></span>
                                </div>
                                <div class="bggocnhin clearfix" style="height: 129px;">
                                    <div class="boxleft">
                                        <a href="/xung-dot-my-iran-can-trong-tac-dong-bat-ngo-den-viet-nam-20200107092244345.chn" title="Xung đột Mỹ - Iran: Cẩn trọng tác động bất ngờ đến Việt Nam" class="title">Xung đột Mỹ - Iran: Cẩn trọng tác động bất ngờ đến Việt Nam</a>
                                            <div class="chuyengia">
                                                <a href="/bai-viet-cua-chuyen-gia-ts-vo-tri-thanh-14.chn" title="TS. Võ Trí Thành">
                                                    <p class="name">TS. Võ Trí Thành</p></a>
                                    </div></div>
                                    <div class="boxright">
                                        <a href="/bai-viet-cua-chuyen-gia-ts-vo-tri-thanh-14.chn" title="TS. Võ Trí Thành"><img src="http://cafefcdn.com/zoom/70_70/2016/c2b48-vo-tri-thanh-1421749905899-1452063978481.jpg" alt="TS. Võ Trí Thành"></a></div>

                            </div>
                        </div><div class="chuyengia_bg clearfix">
                                <div class="chuyengian-quote">
                                    <span class="icon_quote sprite"></span>
                                </div>
                                <div class="bggocnhin clearfix" style="height: 151px;">
                                    <div class="boxleft">
                                        <a href="/chuyen-gia-nguyen-tri-hieu-can-thanh-tra-lai-he-so-car-cua-cac-ngan-hang-ap-dung-thong-tu-41-20200106150554439.chn" title="Chuyên gia Nguyễn Trí Hiếu: Cần thanh tra lại hệ số CAR của các ngân hàng áp dụng Thông tư 41" class="title">Chuyên gia Nguyễn Trí Hiếu: Cần thanh tra lại hệ số CAR của các ngân hàng áp dụng Thông tư 41</a>
                                            <div class="chuyengia">
                                                <a href="/bai-viet-cua-chuyen-gia-ts-nguyen-tri-hieu-38.chn" title="TS. Nguyễn Trí Hiếu">
                                                    <p class="name">TS. Nguyễn Trí Hiếu</p></a>
                                    </div></div>
                                    <div class="boxright">
                                        <a href="/bai-viet-cua-chuyen-gia-ts-nguyen-tri-hieu-38.chn" title="TS. Nguyễn Trí Hiếu"><img src="http://cafefcdn.com/zoom/70_70/2017/ts-nguyen-tri-hieu-1427419958179-1452063833672-crop-1452063859729-1489375221402.png" alt="TS. Nguyễn Trí Hiếu"></a></div>

                            </div>
                        </div><div class="chuyengia_bg clearfix">
                                <div class="chuyengian-quote">
                                    <span class="icon_quote sprite"></span>
                                </div>
                                <div class="bggocnhin clearfix" style="height: 107px;">
                                    <div class="boxleft">
                                        <a href="/3-kich-ban-lam-phat-nam-2020-20200104093443205.chn" title="3 kịch bản lạm phát năm 2020" class="title">3 kịch bản lạm phát năm 2020</a>
                                            <div class="chuyengia">
                                                <a href="/bai-viet-cua-chuyen-gia-ts-nguyen-duc-do-6.chn" title="TS. Nguyễn Đức Độ">
                                                    <p class="name">TS. Nguyễn Đức Độ</p></a>
                                    </div></div>
                                    <div class="boxright">
                                        <a href="/bai-viet-cua-chuyen-gia-ts-nguyen-duc-do-6.chn" title="TS. Nguyễn Đức Độ"><img src="http://cafefcdn.com/zoom/70_70/2019/3/22/photo-2-15532155020162117278634.png" alt="TS. Nguyễn Đức Độ"></a></div>

                            </div>
                        </div>
        </div>
    </div>

                            </div>
                            <ul class="listchungkhoannew">



            <li class="tlitem clearfix top" data-newsid="20200107093340002">
                <a class="avatar " href="/go-kho-cho-dau-tau-kinh-te-20200107093340002.chn" title="Gỡ khó cho đầu tàu kinh tế"><img src="http://cafefcdn.com/zoom/260_162/2020/photo1578364246271-1578364246413-crop-15783643354511241693825.jpg" alt="Gỡ khó cho đầu tàu kinh tế" title="Gỡ khó cho đầu tàu kinh tế"></a>
                <div class="knswli-right">
                    <h3><a href="/go-kho-cho-dau-tau-kinh-te-20200107093340002.chn" title="Gỡ khó cho đầu tàu kinh tế">Gỡ khó cho đầu tàu kinh tế</a></h3>
                    <p class="time_cate ">
                        <a href="vi-mo-dau-tu.chn" title="Kinh tế vĩ mô - Đầu tư ">Kinh tế vĩ mô - Đầu tư </a>
                        <span class="gachngoai">-<span>
                            <span class="time" title="2020-01-07T19:36:32">2 giờ trước</span>
                    </span></span></p>
                    <p class="sapo">Ngày 6/1, tại hội nghị triển khai nhiệm vụ phát triển kinh tế - xã hội năm 2020, Chủ tịch UBND TPHCM Nguyễn Thành Phong thừa nhận việc hoàn thành các mục tiêu, nhiệm vụ đề ra sẽ...</p>
                </div>
            </li>

            <li class="tlitem clearfix" data-newsid="20200107095714736">
                <a class="avatar " href="/co-quan-kinh-te-dai-loan-noi-gi-ve-viec-dau-tu-vao-linh-vuc-san-xuat-hang-cong-nghe-cao-o-viet-nam-20200107095714736.chn" title="Cơ quan Kinh tế Đài Loan nói gì về việc đầu tư vào lĩnh vực sản xuất hàng công nghệ cao ở Việt Nam?"><img src="http://cafefcdn.com/zoom/260_162/2020/1/7/960x640450058269908-1578365676579376078791-crop-15783657162171928401395.jpg" alt="Cơ quan Kinh tế Đài Loan nói gì về việc đầu tư vào lĩnh vực sản xuất hàng công nghệ cao ở Việt Nam?" title="Cơ quan Kinh tế Đài Loan nói gì về việc đầu tư vào lĩnh vực sản xuất hàng công nghệ cao ở Việt Nam?"></a>
                <div class="knswli-right">
                    <h3><a href="/co-quan-kinh-te-dai-loan-noi-gi-ve-viec-dau-tu-vao-linh-vuc-san-xuat-hang-cong-nghe-cao-o-viet-nam-20200107095714736.chn" title="Cơ quan Kinh tế Đài Loan nói gì về việc đầu tư vào lĩnh vực sản xuất hàng công nghệ cao ở Việt Nam?">Cơ quan Kinh tế Đài Loan nói gì về việc đầu tư vào lĩnh vực sản xuất hàng công nghệ cao ở Việt Nam?</a></h3>
                    <p class="time_cate ">
                        <a href="vi-mo-dau-tu.chn" title="Kinh tế vĩ mô - Đầu tư ">Kinh tế vĩ mô - Đầu tư </a>
                        <span class="gachngoai">-<span>
                            <span class="time" title="2020-01-07T19:36:14">2 giờ trước</span>
                    </span></span></p>
                    <p class="sapo">Đài Loan đã trở thành nhà đầu tư nước ngoài lớn thứ 5 tại Việt Nam trong 11 tháng đầu năm 2019, Cục thống kê của Cơ quan Kinh tế Đài Loan (MOEA) đã báo cáo hôm 6/1.</p>
                </div>
            </li>

            <li class="tlitem clearfix" data-newsid="20200107092244345">
                <a class="avatar " href="/xung-dot-my-iran-can-trong-tac-dong-bat-ngo-den-viet-nam-20200107092244345.chn" title="Xung đột Mỹ - Iran: Cẩn trọng tác động bất ngờ đến Việt Nam"><img src="http://cafefcdn.com/zoom/260_162/2020/photo1578363665658-1578363665701-crop-15783637136121911259250.jpg" alt="Xung đột Mỹ - Iran: Cẩn trọng tác động bất ngờ đến Việt Nam" title="Xung đột Mỹ - Iran: Cẩn trọng tác động bất ngờ đến Việt Nam"></a>
                <div class="knswli-right">
                    <h3><a href="/xung-dot-my-iran-can-trong-tac-dong-bat-ngo-den-viet-nam-20200107092244345.chn" title="Xung đột Mỹ - Iran: Cẩn trọng tác động bất ngờ đến Việt Nam">Xung đột Mỹ - Iran: Cẩn trọng tác động bất ngờ đến Việt Nam</a></h3>
                    <p class="time_cate ">
                        <a href="tai-chinh-ngan-hang.chn" title="Tài chính - ngân hàng">Tài chính - ngân hàng</a>
                        <span class="gachngoai">-<span>
                            <span class="time" title="2020-01-07T09:28:07">12 giờ trước</span>
                    </span></span></p>
                    <p class="sapo">Tình hình căng thẳng giữa Mỹ và Iran sẽ tạo ra nhiều yếu tố bất định tác động đến nền kinh tế Việt Nam, gây áp lực đến các mục tiêu vĩ mô.</p>
                </div>
            </li>

            <li class="tlitem clearfix" data-newsid="20200107145236814">
                <a class="avatar " href="/90-nguoi-dau-tu-vao-chung-cu-den-thoi-diem-nay-ban-ra-deu-bi-lo-20200107145236814.chn" title="&quot;90% người đầu tư vào chung cư đến thời điểm này bán ra đều bị lỗ&quot;?"><img src="http://cafefcdn.com/zoom/260_162/2020/1/7/c06c6d2cd8283b766239-min-1578383454550767538961-crop-1578383466884670648063.jpg" alt="&quot;90% người đầu tư vào chung cư đến thời điểm này bán ra đều bị lỗ&quot;?" title="&quot;90% người đầu tư vào chung cư đến thời điểm này bán ra đều bị lỗ&quot;?"></a>
                <div class="knswli-right">
                    <h3><a href="/90-nguoi-dau-tu-vao-chung-cu-den-thoi-diem-nay-ban-ra-deu-bi-lo-20200107145236814.chn" title="&quot;90% người đầu tư vào chung cư đến thời điểm này bán ra đều bị lỗ&quot;?">"90% người đầu tư vào chung cư đến thời điểm này bán ra đều bị lỗ"?</a></h3>
                    <p class="time_cate ">
                        <a href="bat-dong-san.chn" title="Bất động sản">Bất động sản</a>
                        <span class="gachngoai">-<span>
                            <span class="time" title="2020-01-07T14:52:48">7 giờ trước</span>
                    </span></span></p>
                    <p class="sapo">Sau giai đoạn tiêu thụ quá nhiều, nhà đầu tư lao vào mua bán, hiện nay phân khúc căn hộ chung cư không còn là lựa chọn đầu tư lướt sóng trên thị trường.</p>
                </div>
            </li>

            <li class="tlitem clearfix" data-newsid="20200107092758845">
                <a class="avatar " href="/gia-nha-dat-ha-nhiet-20200107092758845.chn" title="Giá nhà đất hạ nhiệt"><img src="http://cafefcdn.com/zoom/260_162/2020/photo1578364002981-1578364003022-crop-157836402313165907526.jpg" alt="Giá nhà đất hạ nhiệt" title="Giá nhà đất hạ nhiệt"></a>
                <div class="knswli-right">
                    <h3><a href="/gia-nha-dat-ha-nhiet-20200107092758845.chn" title="Giá nhà đất hạ nhiệt">Giá nhà đất hạ nhiệt</a></h3>
                    <p class="time_cate ">
                        <a href="bat-dong-san.chn" title="Bất động sản">Bất động sản</a>
                        <span class="gachngoai">-<span>
                            <span class="time" title="2020-01-07T09:59:00">12 giờ trước</span>
                    </span></span></p>
                    <p class="sapo">Các chuyên gia nhận định dấu hiệu chững lại của thị trường bất động sản đã lộ rõ.</p>
                </div>
            </li>




    <div id="admzone472008"><div id="zone-472008"><div id="share-jtgyrhmq"><div id="placement-507332" revenue="pb"><div id="banner-472008-507332" style="min-height: 10px; min-width: 10px;"><div id="slot-1-472008-507332"><div id="sponsorzone_472073"></div>
                            <script type="text/javascript">
                            var adm_location = "1";
                            try{
                              adm_location = Arf.detail.getValue('__R');
                              if(adm_location == "0"){adm_location = "1" }
                            }catch(e){}
                            Arf.utils.loadScript("//media1.admicro.vn/adn/sponsorzone_472073_"+adm_location+".js")

                            </script></div></div></div></div> </div></div>
    <script>
        admicroAD.unit.push(function () { admicroAD.show('admzone472008') });
    </script>

                            </ul>



                            <div data-check-position="cf_home-position_b2"></div>
                            <div class="higlight_box clearfix row2 nobd" data-marked-zoneid="cf_home_b2">

    <div class="boxexamination">
        <div class="title">
            <p class="text-examination">Sự kiện : </p>
            <h2 class="toppicbig"><a href="/su-kien/734-ket-qua-kinh-doanh-2019.chn" title="KẾT QUẢ KINH DOANH 2019">KẾT QUẢ KINH DOANH 2019</a></h2>
        </div>
        <ul class="news-list">

                    <li style="height: 300px;">
                        <a href="/loc-dau-dung-quat-bsr-lai-rong-nam-2019-dat-2200-ty-len-ke-hoach-2020-khiem-ton-voi-1289-ty-20200104092955752.chn" title="Lọc dầu Dung Quất (BSR): Lãi ròng năm 2019 đạt 2.200 tỷ, lên kế hoạch 2020 khiêm tốn với 1.289 tỷ" class="img230x144">
                            <img src="http://cafefcdn.com/zoom/230_144/2019/12/2/bsr-avar-15752851519331972898443-crop-1578104841720867935711.png" class="img230x144" alt="Lọc dầu Dung Quất (BSR): Lãi ròng năm 2019 đạt 2.200 tỷ, lên kế hoạch 2020 khiêm tốn với 1.289 tỷ">
                        </a>
                        <div class="name-news">
                            <a href="/loc-dau-dung-quat-bsr-lai-rong-nam-2019-dat-2200-ty-len-ke-hoach-2020-khiem-ton-voi-1289-ty-20200104092955752.chn" title="Lọc dầu Dung Quất (BSR): Lãi ròng năm 2019 đạt 2.200 tỷ, lên kế hoạch 2020 khiêm tốn với 1.289 tỷ" class="title-news">Lọc dầu Dung Quất (BSR): Lãi ròng năm 2019 đạt 2.200 tỷ, lên kế hoạch 2020 khiêm tốn với 1.289 tỷ
                            </a>
                            <a href="/thi-truong-chung-khoan.chn" title="Thị trường chứng khoán" class="category-news">Thị trường chứng khoán</a>
                        </div>

                    </li>

                    <li style="height: 300px;">
                        <a href="/tap-doan-cao-su-viet-nam-gvr-uoc-lai-truoc-thue-hon-5100-ty-dong-trong-nam-2019-20191231103140638.chn" title="Tập đoàn Cao su Việt Nam (GVR) ước lãi trước thuế hơn 5.100 tỷ đồng trong năm 2019" class="img230x144">
                            <img src="http://cafefcdn.com/zoom/230_144/2019/12/31/45hemv-15777629597191622862148-crop-1577762968259798740426.jpg" class="img230x144" alt="Tập đoàn Cao su Việt Nam (GVR) ước lãi trước thuế hơn 5.100 tỷ đồng trong năm 2019">
                        </a>
                        <div class="name-news">
                            <a href="/tap-doan-cao-su-viet-nam-gvr-uoc-lai-truoc-thue-hon-5100-ty-dong-trong-nam-2019-20191231103140638.chn" title="Tập đoàn Cao su Việt Nam (GVR) ước lãi trước thuế hơn 5.100 tỷ đồng trong năm 2019" class="title-news">Tập đoàn Cao su Việt Nam (GVR) ước lãi trước thuế hơn 5.100 tỷ đồng trong năm 2019
                            </a>
                            <a href="/thi-truong-chung-khoan.chn" title="Thị trường chứng khoán" class="category-news">Thị trường chứng khoán</a>
                        </div>

                    </li>

                    <li style="height: 300px;">
                        <a href="/duong-quang-ngai-qns-uoc-lai-hop-nhat-sau-thue-hon-1200-ty-dong-giam-nhe-so-voi-2018-2019123013571631.chn" title="Đường Quảng Ngãi (QNS) ước lãi hợp nhất sau thuế hơn 1.200 tỷ đồng, giảm nhẹ so với 2018" class="img230x144">
                            <img src="http://cafefcdn.com/zoom/230_144/2019/12/30/5350yyyngquyngngai-1577688974511246968864-crop-15776889805791703557212.jpg" class="img230x144" alt="Đường Quảng Ngãi (QNS) ước lãi hợp nhất sau thuế hơn 1.200 tỷ đồng, giảm nhẹ so với 2018">
                        </a>
                        <div class="name-news">
                            <a href="/duong-quang-ngai-qns-uoc-lai-hop-nhat-sau-thue-hon-1200-ty-dong-giam-nhe-so-voi-2018-2019123013571631.chn" title="Đường Quảng Ngãi (QNS) ước lãi hợp nhất sau thuế hơn 1.200 tỷ đồng, giảm nhẹ so với 2018" class="title-news">Đường Quảng Ngãi (QNS) ước lãi hợp nhất sau thuế hơn 1.200 tỷ đồng, giảm nhẹ so với 2018
                            </a>
                            <a href="/thi-truong-chung-khoan.chn" title="Thị trường chứng khoán" class="category-news">Thị trường chứng khoán</a>
                        </div>

                    </li>

        </ul>
    </div>



                                <div class="clearfix"></div>
                            </div>

                        </div>

                        <div class="clearfix"></div>
                        <div class="top5_news mt-0">
                            <ul class="listchungkhoannew" id="hasWechoice">


            <li class="tlitem clearfix top" data-newsid="20200107085207064">
                <a class="avatar " href="/uong-nuoc-nhieu-nhung-van-thay-kho-mieng-hay-can-than-boi-day-la-dau-hieu-cua-hang-loat-benh-nguy-hiem-20200107085207064.chn" title="Uống nước nhiều nhưng vẫn thấy khô miệng, hãy cẩn thận bởi đây là dấu hiệu của hàng loạt bệnh nguy hiểm"><img src="http://cafefcdn.com/zoom/260_162/2020/1/7/xerostomiaportada02082015consalud-1578284988311505491375-crop-1578285008278223821049-1578361831960105670306-crop-1578361834955213186004.jpg" alt="Uống nước nhiều nhưng vẫn thấy khô miệng, hãy cẩn thận bởi đây là dấu hiệu của hàng loạt bệnh nguy hiểm" title="Uống nước nhiều nhưng vẫn thấy khô miệng, hãy cẩn thận bởi đây là dấu hiệu của hàng loạt bệnh nguy hiểm"></a>
                <div class="knswli-right">
                    <h3><a href="/uong-nuoc-nhieu-nhung-van-thay-kho-mieng-hay-can-than-boi-day-la-dau-hieu-cua-hang-loat-benh-nguy-hiem-20200107085207064.chn" title="Uống nước nhiều nhưng vẫn thấy khô miệng, hãy cẩn thận bởi đây là dấu hiệu của hàng loạt bệnh nguy hiểm">Uống nước nhiều nhưng vẫn thấy khô miệng, hãy cẩn thận bởi đây là dấu hiệu của hàng loạt bệnh nguy hiểm</a></h3>
                    <p class="time_cate ">
                        <a href="song.chn" title="Sống">Sống</a>
                        <span class="gachngoai">-<span>
                            <span class="time" title="2020-01-07T21:04:02">1 giờ trước</span>
                    </span></span></p>
                    <p class="sapo">Khô miệng tưởng chừng là một dấu hiệu bình thường, thế nhưng trong một vài trường hợp nó lại cho thấy cơ thể đang gặp những vấn đề sức khỏe nghiêm trọng.</p>
                </div>
            </li>

            <li class="tlitem clearfix" data-newsid="20200107165507064">
                <a class="avatar " href="/o-nhiem-bui-min-o-ha-noi-nguoi-dan-chuyen-ra-ngoai-trung-tam-mua-nha-20200107165507064.chn" title="Ô nhiễm bụi mịn ở Hà Nội, người dân chuyển ra ngoài trung tâm mua nhà"><img src="http://cafefcdn.com/zoom/260_162/2020/photo1578390817743-1578390817851-crop-15783908273461514760647.jpg" alt="Ô nhiễm bụi mịn ở Hà Nội, người dân chuyển ra ngoài trung tâm mua nhà" title="Ô nhiễm bụi mịn ở Hà Nội, người dân chuyển ra ngoài trung tâm mua nhà"></a>
                <div class="knswli-right">
                    <h3><a href="/o-nhiem-bui-min-o-ha-noi-nguoi-dan-chuyen-ra-ngoai-trung-tam-mua-nha-20200107165507064.chn" title="Ô nhiễm bụi mịn ở Hà Nội, người dân chuyển ra ngoài trung tâm mua nhà">Ô nhiễm bụi mịn ở Hà Nội, người dân chuyển ra ngoài trung tâm mua nhà</a></h3>
                    <p class="time_cate ">
                        <a href="bat-dong-san.chn" title="Bất động sản">Bất động sản</a>
                        <span class="gachngoai">-<span>
                            <span class="time" title="2020-01-07T20:49:26">1 giờ trước</span>
                    </span></span></p>
                    <p class="sapo">Bà Dương Thùy Dung, Giám đốc cấp cao, Trưởng bộ phận nghiên cứu CBRE Việt Nam cho biết, ô nhiễm môi trường từ khói bụi, tiếng ồn, kẹt xe tại trung tâm thành phố khiến người dân...</p>
                </div>
            </li><li class="wechoice-video-single knswli clearfix">


                            </ul>
                        </div>
                        <div class="banner_right3">
                        </div>
                    </div>
