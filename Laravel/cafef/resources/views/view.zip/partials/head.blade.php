<head id="Head1" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# article: http://ogp.me/ns/article#"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /><meta name="google-site-verification" content="zSSanpIa4FRAFCxNc-4pe6kB-_Zx2ZZTC3V-Zaio-aM" /><title>Kênh thông tin kinh tế - tài chính Việt Nam</title><meta id="metakeywords" name="keywords" content="kinh tế,tài chính,chứng khoán,vnindex,hnx-index,upcom,hose,cập nhật,thông tin,chính xác,liên tục" /><meta id="newskeywords" name="news_keywords" content="kinh tế,tài chính,chứng khoán,vnindex,hnx-index,upcom,hose,cập nhật,thông tin,chính xác,liên tục" /><meta id="metaDes" name="description" content="CafeF - Kênh tin tức kinh tế, tài chính, thông tin chứng khoán của Việt Nam mới nhất được cập nhật liên tục, chính xác và đầy đủ,chuyên sâu" /><meta http-equiv="refresh" content="7200" /><meta name="robots" content="index,follow" /><link rel="canonical" href="http://cafef.vn/" />
    <link rel="alternate" type="application/rss+xml" href="http://cafef.vn/home.rss" title="Kênh thông tin kinh tế - tài chính Việt Nam" />
    <link rel="alternate" media="only screen and (max-width: 640px)" href="http://m.cafef.vn/" />
    <link rel="alternate" media="handheld" href="http://m.cafef.vn/" />

            <meta property="og:type" content="article" />
            <meta prefix="fb: http://ogp.me/ns/fb#" property="fb:app_id" content="115279665149396" />


        <script type="text/javascript">
            var servertime = parseFloat('210545'); var sDomain = 'http://s.cafef.vn'; var apiDomain = 'http://e.cafef.vn'; var ajaxDomainPopup = 'http://cafefs.cnnd.vn'; //'http://a12.channelvn.net' ;
            var ajaxDomain = 'http://online1.cafef.vn'; var storageDomain = 'http://cafefcdn.com'; var newversion = 1;
            var admDomainv2 = "http://nspapi.aiservice.vn"; //"http://nspapi.aiservice.vn";
        </script>

            <link rel="dns-prefetch" href="http://cafefcdn.com"/>
            <link rel="shortcut icon" href="http://cafef3.mediacdn.vn/v2/images/favicon.ico" />



        <link href="http://cafefcdn.com/web_css/csshome.min.20200106v1.css" rel="stylesheet" type="text/css" />







            <script type="text/javascript" src="http://cafefcdn.com/frontend/scripts/kby_v1.js" async></script>
            <script type="text/javascript">
                try {
                    if (navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry|Windows Phone|webOS)/i) != null) {
                        var html = document.getElementById('html');
                        if (html && !html.classList.contains('smartphone')) {
                            html.classList.add('smartphone');
                        }
                    }
                } catch (e) { }
            </script>
            <!--[if lte IE 6]>
                <script type="text/javascript" src="http://cafef3.vcmedia.vn/v2/ie/iepngfix_tilebg.js"></script>
            <![endif]-->

        <meta itemprop="thumbnailUrl" property="og:image" content="http://cafefcdn.com/web_images/cafeF-1200x630.jpg" />
        <meta property="og:url" content="http://cafef.vn/" />
        <script type="text/javascript">
            var _ADM_Channel = '%2fhome%2f';
        </script>

    <script async type='text/javascript' src="//media1.admicro.vn/core/adm_tracking.js"></script>


    <!-- Admicro Tag Manager -->
    <script> (function (a, b, d, c, e) {
    a[c] = a[c] || [];
         a[c].push({ "atm.start": (new Date).getTime(), event: "atm.js" });
         a = b.getElementsByTagName(d)[0]; b = b.createElement(d); b.async = !0;
         b.src = "//deqik.com/tag/corejs/" + e + ".js"; a.parentNode.insertBefore(b, a)
     })(window, document, "script", "atmDataLayer", "ATMN0D99DK99S");</script>
    <!-- End Admicro Tag Manager -->
        <script async src="https://static.amcdn.vn/tka/cdn.js" type="text/javascript"></script>
        <script>
            (function () {
                var img = new Image();
                var pt = (document.location.protocol == "https:" ? "https:" : "http:");
                img.src = pt + '//lg1.logging.admicro.vn/ftest?url=' + encodeURIComponent(document.URL);
                var img1 = new Image();
                img1.src = pt + '//amcdn.vn/ftest?url=' + encodeURIComponent(document.URL);
            })();
        </script>


    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-34575478-17"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'UA-34575478-17');
    </script>
        <script type="text/javascript">
            var admicroAD = admicroAD || {};
            admicroAD.unit = admicroAD.unit || [];
        </script>
        <script type="text/javascript" src="//media1.admicro.vn/core/admcore.js" async onerror="window.admerrorload=true;"></script>
        <script type="text/javascript" src="http://media1.admicro.vn/core/log_cafef.js" async></script>

            </head>
